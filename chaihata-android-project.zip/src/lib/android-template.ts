import JSZip from "jszip";

export const ANDROID_MANIFEST_XML = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.chaihata.prottayon">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar"
        android:usesCleartextTraffic="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

export const MAIN_ACTIVITY_JAVA = `package com.chaihata.prottayon;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView myWebView;
    private ProgressBar progressBar;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progressBar);

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);

        // Native Android Print Interface (Handles window.print())
        myWebView.addJavascriptInterface(new WebAppInterface(this), "AndroidNative");

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                
                // Inject override for window.print() to call Android native PrintManager
                view.loadUrl("javascript:(function() { " +
                        "window.print = function() { AndroidNative.printDocument(); }; " +
                        "})()");
            }
        });

        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });

        // Load local offline assets or live server
        myWebView.loadUrl("file:///android_asset/certificate.html");
    }

    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void printDocument() {
            runOnUiThread(() -> {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager != null) {
                    PrintDocumentAdapter printAdapter = myWebView.createPrintDocumentAdapter("প্রত্যয়ন_পত্র");
                    String jobName = getString(R.string.app_name) + " Print Job";
                    PrintAttributes.Builder builder = new PrintAttributes.Builder();
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape());
                    builder.setColorMode(PrintAttributes.COLOR_MODE_COLOR);
                    PrintJob printJob = printManager.print(jobName, printAdapter, builder.build());
                } else {
                    Toast.makeText(mContext, "প্রিন্ট সেবা পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && myWebView.canGoBack()) {
            myWebView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
`;

export const ACTIVITY_MAIN_XML = `<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="4dp"
        android:indeterminate="false"
        android:max="100"
        android:visibility="gone"
        android:progressDrawable="@drawable/progress_bar_custom" />

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_below="@id/progressBar" />

</RelativeLayout>
`;

export const PROGRESS_BAR_DRAWABLE = `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/background">
        <color android:color="#e2e8f0" />
    </item>
    <item android:id="@android:id/progress">
        <clip>
            <color android:color="#1e56a0" />
        </clip>
    </item>
</layer-list>
`;

export const STRINGS_XML = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">প্রত্যয়ন পত্র</string>
    <string name="school_name">ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়</string>
</resources>
`;

export const COLORS_XML = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#1e56a0</color>
    <color name="colorPrimaryDark">#15407a</color>
    <color name="colorAccent">#c59b27</color>
    <color name="colorBackground">#f8fafc</color>
</resources>
`;

export const APP_BUILD_GRADLE = `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.chaihata.prottayon'
    compileSdk 34

    defaultConfig {
        applicationId "com.chaihata.prottayon"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
}
`;

export const PROJECT_BUILD_GRADLE = `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`;

export const SETTINGS_GRADLE = `rootProject.name = "ChaihataProttayon"
include ':app'
`;

export const README_MD = `# ছাইহাটা প্রাথমিক বিদ্যালয় — প্রত্যয়ন পত্র অ্যান্ড্রয়েড অ্যাপ সোর্স কোড (Android Studio Project)

এটি সম্পূর্ণ রেডি-টু-বিল্ড অ্যান্ড্রয়েড স্টুডিও (Android Studio) প্রোজেক্ট। 

### 📱 অ্যাপের বৈশিষ্ট্য:
1. **১০০% অফলাইনে চলে:** অ্যাপের ভেতর \`assets/certificate.html\` ফাইলটি দেওয়া আছে। ইন্টারনেট ছাড়াই গ্রামে বা যেকোনো স্থানে সম্পূর্ণ অফলাইনে চলবে।
2. **লোকাল ডাটাবেজ:** সকল ছাত্রের তথ্য ও স্কুলের সেটিংস ফোনের ভেতরে সংরক্ষিত থাকবে।
3. **সরাসরি A4 প্রিন্ট ও PDF:** অ্যাপের মধ্যে \`প্রিন্ট\` বোতাম চাপলে সরাসরি অ্যান্ড্রয়েডের নেটিভ প্রিন্ট ডায়ালগ ওপেন হবে (WiFi প্রিন্টার অথবা Save as PDF)।
4. **১-ক্লিকে যেকোনো এডিট:** ছাত্রের নাম, রোল, তারিখ সব সরাসরি এডিট করা যায়।

### 🛠️ কিভাবে APK তৈরি করবেন:
1. এই জিপ ফাইলটি আনজিপ করুন।
2. **Android Studio** ওপেন করে \`Open an Existing Project\` নির্বাচন করুন এবং এই ফোল্ডারটি দেখান।
3. গ্রেডল সিঙ্ক শেষ হলে মেনু থেকে **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপুন।
4. কয়েক সেকেন্ডের মধ্যে আপনার ফোনের জন্য \`app-debug.apk\` তৈরি হয়ে যাবে!
5. ক্যাবল বা ব্লুটুথ দিয়ে ফোনে নিয়ে ইন্সটল করুন।
`;

export async function createAndroidProjectZip(htmlContent: string): Promise<Blob> {
  const zip = new JSZip();

  // Root files
  zip.file("README_ANDROID_BUILD.md", README_MD);
  zip.file("build.gradle", PROJECT_BUILD_GRADLE);
  zip.file("settings.gradle", SETTINGS_GRADLE);
  zip.file("gradle.properties", "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n");

  // App module
  zip.file("app/build.gradle", APP_BUILD_GRADLE);
  zip.file("app/src/main/AndroidManifest.xml", ANDROID_MANIFEST_XML);

  // Java source
  zip.file(
    "app/src/main/java/com/chaihata/prottayon/MainActivity.java",
    MAIN_ACTIVITY_JAVA
  );

  // Layout & Drawables
  zip.file("app/src/main/res/layout/activity_main.xml", ACTIVITY_MAIN_XML);
  zip.file("app/src/main/res/drawable/progress_bar_custom.xml", PROGRESS_BAR_DRAWABLE);

  // Values
  zip.file("app/src/main/res/values/strings.xml", STRINGS_XML);
  zip.file("app/src/main/res/values/colors.xml", COLORS_XML);

  // Assets (HTML inside APK)
  zip.file("app/src/main/assets/certificate.html", htmlContent);

  return await zip.generateAsync({ type: "blob" });
}
