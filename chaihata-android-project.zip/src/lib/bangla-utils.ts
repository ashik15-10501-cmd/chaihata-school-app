export const BENGALI_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
export const ENGLISH_DIGITS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

export function toBengaliDigits(input: string | number | undefined | null): string {
  if (input === undefined || input === null) return "";
  const str = String(input);
  return str.replace(/[0-9]/g, (digit) => BENGALI_DIGITS[parseInt(digit, 10)]);
}

export function toEnglishDigits(input: string | number | undefined | null): string {
  if (input === undefined || input === null) return "";
  const str = String(input);
  return str.replace(/[০-৯]/g, (bengaliChar) => {
    const idx = BENGALI_DIGITS.indexOf(bengaliChar);
    return idx !== -1 ? String(idx) : bengaliChar;
  });
}

export function getTodayDateBengali(): string {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, "0");
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const year = String(now.getFullYear());
  return `${toBengaliDigits(day)}/${toBengaliDigits(month)}/${toBengaliDigits(year)} খ্রি:`;
}

export function getTodayDateEnglish(): string {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, "0");
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const year = String(now.getFullYear());
  return `${day}/${month}/${year} খ্রি:`;
}

export interface CertificateData {
  schoolName: string;
  establishedYear: string;
  village: string;
  postOffice: string;
  thanaUpazila: string;
  district: string;
  ministryName: string;
  departmentName: string;
  directorateName: string;
  memoNo: string;
  issueDate: string;
  certificateType: string;
  studentName: string;
  fatherName: string;
  motherName: string;
  studentVillage: string;
  studentPostOffice: string;
  studentThana: string;
  studentDistrict: string;
  academicYear: string;
  studentClass: string;
  rollNo: string;
  gender: string; // "ছাত্র" | "ছাত্রী"
  dateOfBirth: string;
  birthRegNo?: string;
  characterRemark?: string;
  headTeacherName: string;
  headTeacherTitle: string;
  classTeacherTitle: string;
  borderStyle?: string;
  showWatermark?: boolean;
  showQrCode?: boolean;
}

export function generateDefaultParagraph1(data: {
  studentName: string;
  fatherName: string;
  motherName: string;
  studentVillage: string;
  studentPostOffice: string;
  studentThana: string;
  studentDistrict: string;
  academicYear: string;
  studentClass: string;
  gender: string;
  rollNo: string;
}): string {
  const studentType = data.gender === "ছাত্রী" ? "ছাত্রী" : "ছাত্র";
  return `এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, ${data.studentName}, পিতা: ${data.fatherName}, মাতা: ${data.motherName}, গ্রাম: ${data.studentVillage}, পোস্ট: ${data.studentPostOffice}, উপজেলা/থানা: ${data.studentThana}, জেলা: ${data.studentDistrict} — এই বিদ্যালয়ের ${data.academicYear} শিক্ষাবর্ষের ${data.studentClass} শ্রেণির একজন নিয়মিত ${studentType}। তার শ্রেণি রোল নং ${data.rollNo}।`;
}

export function generateDefaultParagraph2(data: {
  gender: string;
  characterRemark?: string;
  dateOfBirth: string;
}): string {
  const remark = data.characterRemark || "ভালো";
  return `বিদ্যালয়ের ভর্তি রেকর্ড অনুযায়ী সে অত্র বিদ্যালয়ে নিয়মিতভাবে অধ্যয়ন করেছে। তার আচার-আচরণ ও চরিত্র ${remark}। বিদ্যালয়ের ভর্তি রেকর্ড অনুযায়ী তার জন্ম তারিখ: ${data.dateOfBirth}।`;
}

export function generateDefaultParagraph3(): string {
  return `তার প্রয়োজনীয় কাজে ব্যবহারের জন্য এই প্রত্যয়ন পত্র প্রদান করা হলো। আমি তার সর্বাঙ্গীণ মঙ্গল ও সাফল্য কামনা করি।`;
}

export function generateTransferCertificateParagraph(data: {
  studentName: string;
  fatherName: string;
  motherName: string;
  studentVillage: string;
  studentPostOffice: string;
  studentThana: string;
  studentDistrict: string;
  academicYear: string;
  studentClass: string;
  gender: string;
  rollNo: string;
  dateOfBirth: string;
}): string {
  const studentType = data.gender === "ছাত্রী" ? "ছাত্রী" : "ছাত্র";
  return `এই মর্মে ছাড়পত্র / প্রশংসাপত্র প্রদান করা যাচ্ছে যে, ${data.studentName}, পিতা: ${data.fatherName}, মাতা: ${data.motherName}, গ্রাম: ${data.studentVillage}, ডাকঘর: ${data.studentPostOffice}, উপজেলা: ${data.studentThana}, জেলা: ${data.studentDistrict} — এই বিদ্যালয়ের ${data.academicYear} শিক্ষাবর্ষের ${data.studentClass} শ্রেণির নিয়মিত ${studentType} ছিল। তার শ্রেণি রোল নং ${data.rollNo} এবং জন্ম তারিখ ${data.dateOfBirth}। সে অত্র বিদ্যালয়ে অধ্যয়নকালে কোনো নিয়মশৃঙ্খলা বিরোধী কাজে লিপ্ত ছিল না। তাহার সর্বাঙ্গীন উন্নতি ও ভবিষ্যৎ জীবনের সাফল্য কামনা করি।`;
}

export function generateStipendParagraph(data: {
  studentName: string;
  fatherName: string;
  motherName: string;
  academicYear: string;
  studentClass: string;
  gender: string;
  rollNo: string;
  dateOfBirth: string;
}): string {
  const studentType = data.gender === "ছাত্রী" ? "ছাত্রী" : "ছাত্র";
  return `এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, ${data.studentName}, পিতা: ${data.fatherName}, মাতা: ${data.motherName} — অত্র বিদ্যালয়ের ${data.academicYear} শিক্ষাবর্ষের ${data.studentClass} শ্রেণির নিয়মিত ${studentType}। তার শ্রেণি রোল নং ${data.rollNo} এবং জন্ম তারিখ ${data.dateOfBirth}। সে সরকারি উপবৃত্তি পাওয়ার উপযুক্ত এবং অত্র বিদ্যালয় হতে নিয়মিত প্রাথমিক শিক্ষা উপবৃত্তি ভোগ করে আসছে।`;
}

export function generateAgeParagraph(data: {
  studentName: string;
  fatherName: string;
  motherName: string;
  dateOfBirth: string;
  birthRegNo?: string;
  studentClass: string;
}): string {
  const regText = data.birthRegNo ? ` এবং অনলাইন জন্ম নিবন্ধন নম্বর: ${data.birthRegNo}` : "";
  return `এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, ${data.studentName}, পিতা: ${data.fatherName}, মাতা: ${data.motherName} — বিদ্যালয়ের অফিসিয়াল ভর্তি রেজিস্টার অনুযায়ী তার প্রকৃত জন্ম তারিখ: ${data.dateOfBirth}${regText}। বর্তমানে সে অত্র বিদ্যালয়ের ${data.studentClass} শ্রেণিতে অধ্যয়নরত রয়েছে।`;
}

export function buildStandaloneEditableHtml(data: {
  schoolName: string;
  establishedYear: string;
  village: string;
  postOffice: string;
  thanaUpazila: string;
  district: string;
  ministryName: string;
  departmentName: string;
  directorateName: string;
  memoNo: string;
  issueDate: string;
  certificateType: string;
  p1: string;
  p2: string;
  p3: string;
  headTeacherName: string;
  headTeacherTitle: string;
  classTeacherTitle: string;
  borderStyle: string;
  showWatermark?: boolean;
}): string {
  const borderColor =
    data.borderStyle === "navy"
      ? "#1e3a8a"
      : data.borderStyle === "green"
      ? "#15803d"
      : data.borderStyle === "maroon"
      ? "#881337"
      : "#c59b27";

  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${data.certificateType} - ${data.schoolName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Noto+Serif+Bengali:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      background-color: #f1f5f9;
      font-family: 'Hind Siliguri', 'Noto Serif Bengali', 'SolaimanLipi', Arial, sans-serif;
      color: #111827;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px 10px;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .no-print {
      margin-bottom: 20px;
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      justify-content: center;
      background: white;
      padding: 12px 24px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      max-width: 900px;
      width: 100%;
    }
    .btn {
      background: #1e56a0;
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 15px;
      font-weight: 600;
      border-radius: 6px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: background 0.2s;
      font-family: inherit;
    }
    .btn:hover {
      background: #15407a;
    }
    .btn-green {
      background: #15803d;
    }
    .btn-green:hover {
      background: #0f622d;
    }
    .tip-box {
      font-size: 13px;
      color: #4b5563;
      align-self: center;
    }

    /* Certificate A4 Landscape Canvas */
    .certificate-page {
      width: 297mm;
      min-height: 208mm;
      background: #ffffff;
      padding: 14mm 16mm;
      box-shadow: 0 10px 30px rgba(0,0,0,0.12);
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    /* Outer Border */
    .outer-border {
      position: absolute;
      top: 6mm;
      left: 6mm;
      right: 6mm;
      bottom: 6mm;
      border: 1.5px solid ${borderColor};
      pointer-events: none;
    }
    /* Inner Border */
    .inner-border {
      position: absolute;
      top: 9mm;
      left: 9mm;
      right: 9mm;
      bottom: 9mm;
      border: 5px solid ${borderColor};
      pointer-events: none;
    }

    .certificate-content {
      position: relative;
      z-index: 2;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    /* Watermark */
    .watermark {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      opacity: 0.05;
      pointer-events: none;
      z-index: 1;
      width: 320px;
      height: 320px;
    }

    /* Header */
    .header-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 2px;
    }
    .memo-box {
      font-size: 17px;
      font-weight: 700;
      color: #1f2937;
    }
    .date-box {
      font-size: 17px;
      font-weight: 700;
      color: #1f2937;
    }
    .seal-wrap {
      text-align: center;
      margin-top: -6px;
    }
    .seal-wrap svg {
      width: 65px;
      height: 65px;
      display: block;
      margin: 0 auto;
    }

    .govt-titles {
      text-align: center;
      margin-top: 4px;
      line-height: 1.35;
      font-size: 15px;
      color: #1e293b;
      font-weight: 500;
    }

    .school-title {
      text-align: center;
      font-size: 29px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.3px;
      margin-top: 5px;
      line-height: 1.25;
    }

    .school-sub {
      text-align: center;
      font-size: 15px;
      color: #334155;
      font-weight: 500;
      margin-top: 3px;
      margin-bottom: 12px;
    }

    /* Badge */
    .badge-container {
      text-align: center;
      margin-bottom: 20px;
    }
    .badge-pill {
      display: inline-block;
      background-color: #1e56a0;
      color: white;
      font-size: 19px;
      font-weight: 700;
      padding: 3px 26px;
      border-radius: 4px;
      letter-spacing: 0.5px;
    }

    /* Certificate Body */
    .body-section {
      font-size: 17.5px;
      line-height: 2.1;
      color: #0f172a;
      text-align: justify;
      margin-bottom: 15px;
      flex-grow: 1;
    }
    .body-section p {
      margin-bottom: 16px;
      text-indent: 0;
    }
    .body-section p:last-child {
      margin-bottom: 0;
    }

    /* Signatures */
    .signatures-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      padding-top: 25px;
      margin-top: auto;
    }
    .sign-col {
      text-align: center;
      width: 200px;
    }
    .sign-line {
      border-top: 1.5px solid #1f2937;
      margin-bottom: 6px;
      width: 100%;
    }
    .sign-title {
      font-size: 16px;
      font-weight: 700;
      color: #111827;
    }
    .sign-name {
      font-size: 13.5px;
      color: #4b5563;
      margin-top: 2px;
    }

    /* Inline editable feedback */
    [contenteditable="true"] {
      outline: none;
      transition: background-color 0.2s, box-shadow 0.2s;
      border-radius: 2px;
    }
    [contenteditable="true"]:hover {
      background-color: rgba(234, 179, 8, 0.08);
      cursor: text;
    }
    [contenteditable="true"]:focus {
      background-color: rgba(254, 240, 138, 0.25);
      box-shadow: 0 0 0 1px #eab308;
    }

    @media print {
      @page {
        size: A4 landscape;
        margin: 0;
      }
      body {
        background: transparent !important;
        padding: 0 !important;
      }
      .no-print {
        display: none !important;
      }
      .certificate-page {
        box-shadow: none !important;
        width: 100vw !important;
        height: 100vh !important;
        min-height: 100vh !important;
        padding: 13mm 15mm !important;
        page-break-after: avoid;
        page-break-inside: avoid;
      }
      .outer-border {
        top: 5mm;
        left: 5mm;
        right: 5mm;
        bottom: 5mm;
      }
      .inner-border {
        top: 8mm;
        left: 8mm;
        right: 8mm;
        bottom: 8mm;
      }
      [contenteditable="true"]:hover,
      [contenteditable="true"]:focus {
        background-color: transparent !important;
        box-shadow: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="no-print">
    <button class="btn" onclick="window.print()">
      🖨️ প্রিন্ট করুন (Print / Save as PDF)
    </button>
    <button class="btn btn-green" onclick="alert('আপনি সরাসরি যেকোনো লেখার উপর ক্লিক করে তাৎক্ষণিক পরিবর্তন করতে পারেন!')">
      ✏️ যেকোনো লেখার উপর ক্লিক করে সরাসরি এডিট করুন
    </button>
    <span class="tip-box">
      টিপস: ব্রাউজারের প্রিন্ট অপশনে Margin: None অথবা Minimum দিন এবং Background graphics অন রাখুন।
    </span>
  </div>

  <div class="certificate-page">
    <div class="outer-border"></div>
    <div class="inner-border"></div>

    ${
      data.showWatermark
        ? `<div class="watermark">
            <svg viewBox="0 0 100 100" width="100%" height="100%" fill="none">
              <circle cx="50" cy="50" r="46" stroke="#000" stroke-width="2"/>
              <circle cx="50" cy="50" r="28" fill="#000"/>
              <path d="M50 32 L53 41 L62 41 L55 47 L58 56 L50 51 L42 56 L45 47 L38 41 L47 41 Z" fill="#fff"/>
            </svg>
          </div>`
        : ""
    }

    <div class="certificate-content">
      <div>
        <div class="header-top">
          <div class="memo-box" contenteditable="true">
            স্মারক নং : ${data.memoNo || ".................."}
          </div>
          <div class="seal-wrap">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="50" cy="50" r="48" stroke="#107C41" stroke-width="2.5" fill="#fdfefe"/>
              <circle cx="50" cy="50" r="44.5" stroke="#107C41" stroke-width="1" stroke-dasharray="2 2" fill="none"/>
              <circle cx="50" cy="50" r="28" fill="#F42A41"/>
              <path d="M50 32 L53 41 L62 41 L55 47 L58 56 L50 51 L42 56 L45 47 L38 41 L47 41 Z" fill="#FFD700"/>
              <circle cx="50" cy="46" r="3" fill="#ffffff"/>
              <path id="tp1" d="M 18,50 A 32,32 0 1,1 82,50" fill="none"/>
              <path id="tp2" d="M 82,50 A 32,32 0 0,1 18,50" fill="none"/>
              <text font-size="6.2" font-weight="bold" fill="#006A4E"><textPath href="#tp1" startOffset="50%" text-anchor="middle">গণপ্রজাতন্ত্রী বাংলাদেশ</textPath></text>
              <text font-size="6.2" font-weight="bold" fill="#006A4E"><textPath href="#tp2" startOffset="50%" text-anchor="middle">★ সরকার ★</textPath></text>
            </svg>
          </div>
          <div class="date-box" contenteditable="true">
            তারিখ: ${data.issueDate}
          </div>
        </div>

        <div class="govt-titles" contenteditable="true">
          <div>${data.ministryName}</div>
          <div>${data.departmentName}</div>
          <div>${data.directorateName}</div>
        </div>

        <div class="school-title" contenteditable="true">
          ${data.schoolName}
        </div>

        <div class="school-sub" contenteditable="true">
          স্থাপিত: ${data.establishedYear}, গ্রাম: ${data.village}, ডাকঘর: ${data.postOffice}, উপজেলা: ${data.thanaUpazila}, জেলা: ${data.district}
        </div>

        <div class="badge-container">
          <div class="badge-pill" contenteditable="true">
            ${data.certificateType}
          </div>
        </div>
      </div>

      <div class="body-section">
        <p contenteditable="true">${data.p1}</p>
        <p contenteditable="true">${data.p2}</p>
        <p contenteditable="true">${data.p3}</p>
      </div>

      <div class="signatures-row">
        <div class="sign-col">
          <div class="sign-line"></div>
          <div class="sign-title" contenteditable="true">${data.classTeacherTitle}</div>
        </div>
        <div class="sign-col">
          <div class="sign-line"></div>
          <div class="sign-title" contenteditable="true">${data.headTeacherTitle}</div>
          ${data.headTeacherName ? `<div class="sign-name" contenteditable="true">(${data.headTeacherName})</div>` : ""}
        </div>
      </div>
    </div>
  </div>
</body>
</html>`;
}
