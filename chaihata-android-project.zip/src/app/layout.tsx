import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "প্রত্যয়ন পত্র ও প্রশংসাপত্র জেনারেটর — ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়",
  description:
    "ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়, সারিয়াকান্দি, বগুড়া - শিক্ষার্থীদের প্রত্যয়ন পত্র ও প্রশংসাপত্র প্রস্তুত ও প্রিন্ট সিস্টেম।",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "প্রত্যয়ন পত্র",
  },
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#1e56a0",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="bn">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="প্রত্যয়ন পত্র" />
        <meta name="theme-color" content="#1e56a0" />
      </head>
      <body className="bg-slate-100 text-slate-900 antialiased min-h-screen">
        {children}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js').then(
                    function(registration) {
                      console.log('[PWA] ServiceWorker registration successful');
                    },
                    function(err) {
                      console.log('[PWA] ServiceWorker registration failed: ', err);
                    }
                  );
                });
              }
            `,
          }}
        />
      </body>
    </html>
  );
}
