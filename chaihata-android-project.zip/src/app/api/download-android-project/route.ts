import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { createAndroidProjectZip } from "@/lib/android-template";

export async function GET() {
  try {
    const htmlPath = path.join(process.cwd(), "public", "certificate.html");
    let htmlContent = "";
    if (fs.existsSync(htmlPath)) {
      htmlContent = fs.readFileSync(htmlPath, "utf-8");
    } else {
      htmlContent = "<h1>Chaihata Primary School Certificate App</h1>";
    }

    const zipBlob = await createAndroidProjectZip(htmlContent);
    const arrayBuffer = await zipBlob.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    return new Response(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition":
          'attachment; filename="chaihata-prottayon-android-app-project.zip"',
      },
    });
  } catch (error) {
    console.error("Error creating Android Project zip:", error);
    return NextResponse.json(
      { success: false, error: "Failed to generate Android project zip" },
      { status: 500 }
    );
  }
}
