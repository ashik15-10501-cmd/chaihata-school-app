import { NextResponse } from "next/server";
import { db } from "@/db";
import { schoolSettings } from "@/db/schema";
import { ensureDefaultData } from "@/db/seed";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDefaultData();
    const rows = await db.select().from(schoolSettings).limit(1);
    if (rows.length === 0) {
      return NextResponse.json({ success: false, error: "Settings not found" }, { status: 404 });
    }
    return NextResponse.json({ success: true, data: rows[0] });
  } catch (error) {
    console.error("GET /api/settings error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const rows = await db.select().from(schoolSettings).limit(1);

    const updatePayload = {
      schoolName: body.schoolName ?? "ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়",
      establishedYear: body.establishedYear ?? "১৯৯২",
      village: body.village ?? "ছাইহাটা",
      postOffice: body.postOffice ?? "নিউ সোনাতলা",
      thanaUpazila: body.thanaUpazila ?? "সারিয়াকান্দি",
      district: body.district ?? "বগুড়া",
      division: body.division ?? "রাজশাহী",
      ministryName: body.ministryName ?? "গণপ্রজাতন্ত্রী বাংলাদেশ সরকার",
      departmentName: body.departmentName ?? "প্রাথমিক ও গণশিক্ষা মন্ত্রণালয়",
      directorateName: body.directorateName ?? "প্রাথমিক শিক্ষা অধিদপ্তর",
      memoPrefix: body.memoPrefix ?? "ছাই:পূ:পা:স:প্রা:বি/২০২৬/",
      headTeacherName: body.headTeacherName ?? "মোঃ শফিকুল ইসলাম",
      headTeacherTitle: body.headTeacherTitle ?? "প্রধান শিক্ষক",
      classTeacherTitle: body.classTeacherTitle ?? "শ্রেণি শিক্ষক",
      phone: body.phone ?? "",
      email: body.email ?? "",
      borderStyle: body.borderStyle ?? "gold",
      showWatermark: body.showWatermark !== undefined ? Boolean(body.showWatermark) : true,
      showQrCode: body.showQrCode !== undefined ? Boolean(body.showQrCode) : false,
      updatedAt: new Date(),
    };

    if (rows.length > 0) {
      const updated = await db
        .update(schoolSettings)
        .set(updatePayload)
        .where(eq(schoolSettings.id, rows[0].id))
        .returning();
      return NextResponse.json({ success: true, data: updated[0] });
    } else {
      const inserted = await db.insert(schoolSettings).values(updatePayload).returning();
      return NextResponse.json({ success: true, data: inserted[0] });
    }
  } catch (error) {
    console.error("POST /api/settings error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}
