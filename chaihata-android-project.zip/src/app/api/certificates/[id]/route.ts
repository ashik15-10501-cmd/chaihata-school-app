import { NextResponse } from "next/server";
import { db } from "@/db";
import { savedCertificates } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const certId = parseInt(id, 10);
    if (isNaN(certId)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
    }

    await db.delete(savedCertificates).where(eq(savedCertificates.id, certId));
    return NextResponse.json({ success: true, message: "Certificate deleted" });
  } catch (error) {
    console.error("DELETE /api/certificates/[id] error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}
