import { NextResponse } from "next/server";
import { db } from "@/db";
import { savedCertificates } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const studentId = searchParams.get("studentId");

    let rows;
    if (studentId) {
      rows = await db
        .select()
        .from(savedCertificates)
        .where(eq(savedCertificates.studentId, parseInt(studentId, 10)))
        .orderBy(desc(savedCertificates.id));
    } else {
      rows = await db
        .select()
        .from(savedCertificates)
        .orderBy(desc(savedCertificates.id))
        .limit(100);
    }

    return NextResponse.json({ success: true, data: rows });
  } catch (error) {
    console.error("GET /api/certificates error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const newCert = await db
      .insert(savedCertificates)
      .values({
        studentId: body.studentId ? parseInt(body.studentId, 10) : null,
        certificateType: body.certificateType || "প্রত্যয়ন পত্র",
        memoNo: body.memoNo || "",
        issueDate: body.issueDate || "",
        studentName: body.studentName || "",
        studentClass: body.studentClass || "",
        rollNo: body.rollNo || "",
        academicYear: body.academicYear || "২০২৬",
        fatherName: body.fatherName || "",
        motherName: body.motherName || "",
        village: body.village || "ছাইহাটা",
        postOffice: body.postOffice || "নিউ সোনাতলা",
        thanaUpazila: body.thanaUpazila || "সারিয়াকান্দি",
        district: body.district || "বগুড়া",
        bodyText: body.bodyText || "",
      })
      .returning();

    return NextResponse.json({ success: true, data: newCert[0] });
  } catch (error) {
    console.error("POST /api/certificates error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}
