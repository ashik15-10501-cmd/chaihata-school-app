import { NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const studentId = parseInt(id, 10);
    if (isNaN(studentId)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
    }

    const row = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
    if (row.length === 0) {
      return NextResponse.json({ success: false, error: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: row[0] });
  } catch (error) {
    console.error("GET /api/students/[id] error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const studentId = parseInt(id, 10);
    if (isNaN(studentId)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
    }

    const body = await req.json();

    const updated = await db
      .update(students)
      .set({
        nameBn: body.nameBn?.trim(),
        nameEn: body.nameEn?.trim(),
        rollNo: body.rollNo?.trim(),
        studentClass: body.studentClass?.trim(),
        section: body.section?.trim(),
        academicYear: body.academicYear?.trim(),
        fatherName: body.fatherName?.trim(),
        motherName: body.motherName?.trim(),
        village: body.village?.trim(),
        postOffice: body.postOffice?.trim(),
        thanaUpazila: body.thanaUpazila?.trim(),
        district: body.district?.trim(),
        dateOfBirth: body.dateOfBirth?.trim(),
        birthRegNo: body.birthRegNo?.trim(),
        gender: body.gender?.trim(),
        status: body.status?.trim(),
        characterRemark: body.characterRemark?.trim(),
        phone: body.phone?.trim(),
        notes: body.notes?.trim(),
        updatedAt: new Date(),
      })
      .where(eq(students.id, studentId))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: updated[0] });
  } catch (error) {
    console.error("PUT /api/students/[id] error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const studentId = parseInt(id, 10);
    if (isNaN(studentId)) {
      return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
    }

    await db.delete(students).where(eq(students.id, studentId));
    return NextResponse.json({ success: true, message: "Student deleted successfully" });
  } catch (error) {
    console.error("DELETE /api/students/[id] error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}
