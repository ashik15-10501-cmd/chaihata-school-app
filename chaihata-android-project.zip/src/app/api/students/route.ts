import { NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { ensureDefaultData } from "@/db/seed";
import { desc, ilike, or, eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    await ensureDefaultData();
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search")?.trim();
    const studentClass = searchParams.get("studentClass")?.trim();

    const query = db.select().from(students).orderBy(desc(students.id));

    const allStudents = await query;

    let filtered = allStudents;
    if (search) {
      const lower = search.toLowerCase();
      filtered = filtered.filter(
        (s) =>
          s.nameBn.toLowerCase().includes(lower) ||
          (s.nameEn && s.nameEn.toLowerCase().includes(lower)) ||
          s.rollNo.includes(lower) ||
          s.fatherName.toLowerCase().includes(lower) ||
          s.village.toLowerCase().includes(lower)
      );
    }

    if (studentClass && studentClass !== "all") {
      filtered = filtered.filter((s) => s.studentClass === studentClass);
    }

    return NextResponse.json({ success: true, data: filtered });
  } catch (error) {
    console.error("GET /api/students error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    if (!body.nameBn || !body.rollNo || !body.studentClass) {
      return NextResponse.json(
        { success: false, error: "শিক্ষার্থীর নাম, শ্রেণি এবং রোল নম্বর আবশ্যক।" },
        { status: 400 }
      );
    }

    const newStudent = await db
      .insert(students)
      .values({
        nameBn: body.nameBn.trim(),
        nameEn: body.nameEn?.trim() || "",
        rollNo: body.rollNo.trim(),
        studentClass: body.studentClass.trim(),
        section: body.section?.trim() || "ক",
        academicYear: body.academicYear?.trim() || "২০২৬",
        fatherName: body.fatherName?.trim() || "মোঃ অভিভাবক",
        motherName: body.motherName?.trim() || "মোছাঃ অভিভাবক",
        village: body.village?.trim() || "ছাইহাটা",
        postOffice: body.postOffice?.trim() || "নিউ সোনাতলা",
        thanaUpazila: body.thanaUpazila?.trim() || "সারিয়াকান্দি",
        district: body.district?.trim() || "বগুড়া",
        dateOfBirth: body.dateOfBirth?.trim() || "০১/০১/২০১৫",
        birthRegNo: body.birthRegNo?.trim() || "",
        gender: body.gender?.trim() || "ছাত্র",
        status: body.status?.trim() || "নিয়মিত",
        characterRemark: body.characterRemark?.trim() || "ভালো",
        phone: body.phone?.trim() || "",
        notes: body.notes?.trim() || "",
      })
      .returning();

    return NextResponse.json({ success: true, data: newStudent[0] });
  } catch (error) {
    console.error("POST /api/students error:", error);
    return NextResponse.json({ success: false, error: "Internal Server Error" }, { status: 500 });
  }
}
