"use client";

import React, { useState, useEffect } from "react";
import { SchoolSettings, Student, SavedCertificate } from "@/db/schema";
import {
  CertificateView,
  CertificateState,
} from "@/components/certificate-view";
import { StudentModal } from "@/components/student-modal";
import { SchoolSettingsModal } from "@/components/school-settings-modal";
import { BatchPrintModal } from "@/components/batch-print-modal";
import { AndroidAppModal } from "@/components/android-app-modal";
import { Smartphone } from "lucide-react";
import {
  generateDefaultParagraph1,
  generateDefaultParagraph2,
  generateDefaultParagraph3,
  generateTransferCertificateParagraph,
  generateStipendParagraph,
  generateAgeParagraph,
  getTodayDateBengali,
  toBengaliDigits,
} from "@/lib/bangla-utils";
import {
  FileText,
  Users,
  Settings,
  History,
  PlusCircle,
  Search,
  Filter,
  Check,
  Sparkles,
  Printer,
  Download,
  School,
  UserCheck,
  Edit,
  Trash2,
  Award,
  ArrowRight,
} from "lucide-react";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<"certificate" | "students" | "history">("certificate");

  // School settings
  const [settings, setSettings] = useState<SchoolSettings>({
    id: 1,
    schoolName: "ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়",
    establishedYear: "১৯৯২",
    village: "ছাইহাটা",
    postOffice: "নিউ সোনাতলা",
    thanaUpazila: "সারিয়াকান্দি",
    district: "বগুড়া",
    division: "রাজশাহী",
    ministryName: "গণপ্রজাতন্ত্রী বাংলাদেশ সরকার",
    departmentName: "প্রাথমিক ও গণশিক্ষা মন্ত্রণালয়",
    directorateName: "প্রাথমিক শিক্ষা অধিদপ্তর",
    memoPrefix: "ছাই:পূ:পা:স:প্রা:বি/২০২৬/",
    headTeacherName: "মোঃ শফিকুল ইসলাম",
    headTeacherTitle: "প্রধান শিক্ষক",
    classTeacherTitle: "শ্রেণি শিক্ষক",
    phone: "০১৭১২-৩৪৫৬৭৮",
    email: "",
    borderStyle: "gold",
    showWatermark: true,
    showQrCode: false,
    updatedAt: new Date(),
  });

  // Students list
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [classFilter, setClassFilter] = useState("all");

  // History list
  const [certificatesHistory, setCertificatesHistory] = useState<SavedCertificate[]>([]);

  // Selected student for active certificate
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Modals state
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);

  // Notification toast
  const [toastMessage, setToastMessage] = useState("");

  const defaultP1 =
    "এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, নুর আলম, পিতা: মোঃ অমিত হাসান, মাতা: খাদিজা বেগম, গ্রাম: ছাইহাটা, পোস্ট: নিউ সোনাতলা, উপজেলা/থানা: সারিয়াকান্দি, জেলা: বগুড়া — এই বিদ্যালয়ের ২০২৬ শিক্ষাবর্ষের পঞ্চম শ্রেণির একজন নিয়মিত ছাত্র। তার শ্রেণি রোল নং ২০।";
  const defaultP2 =
    "বিদ্যালয়ের ভর্তি রেকর্ড অনুযায়ী সে অত্র বিদ্যালয়ে নিয়মিতভাবে অধ্যয়ন করেছে। তার আচার-আচরণ ও চরিত্র ভালো। বিদ্যালয়ের ভর্তি রেকর্ড অনুযায়ী তার জন্ম তারিখ: ১৮/১২/২০১৫।";
  const defaultP3 =
    "তার প্রয়োজনীয় কাজে ব্যবহারের জন্য এই প্রত্যয়ন পত্র প্রদান করা হলো। আমি তার সর্বাঙ্গীণ মঙ্গল ও সাফল্য কামনা করি।";

  // Certificate state
  const [certState, setCertState] = useState<CertificateState>({
    schoolName: "ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়",
    establishedYear: "১৯৯২",
    village: "ছাইহাটা",
    postOffice: "নিউ সোনাতলা",
    thanaUpazila: "সারিয়াকান্দি",
    district: "বগুড়া",
    ministryName: "গণপ্রজাতন্ত্রী বাংলাদেশ সরকার",
    departmentName: "প্রাথমিক ও গণশিক্ষা মন্ত্রণালয়",
    directorateName: "প্রাথমিক শিক্ষা অধিদপ্তর",
    memoNo: "ছাই:পূ:পা:স:প্রা:বি/২০২৬/২০",
    issueDate: getTodayDateBengali(),
    certificateType: "প্রত্যয়ন পত্র",
    studentId: undefined,
    studentName: "নুর আলম",
    studentNameEn: "Nur Alam",
    fatherName: "মোঃ অমিত হাসান",
    motherName: "খাদিজা বেগম",
    studentVillage: "ছাইহাটা",
    studentPostOffice: "নিউ সোনাতলা",
    studentThana: "সারিয়াকান্দি",
    studentDistrict: "বগুড়া",
    academicYear: "২০২৬",
    studentClass: "পঞ্চম",
    rollNo: "২০",
    gender: "ছাত্র",
    dateOfBirth: "১৮/১২/২০১৫",
    characterRemark: "ভালো",
    paragraph1: defaultP1,
    paragraph2: defaultP2,
    paragraph3: defaultP3,
    headTeacherName: "মোঃ শফিকুল ইসলাম",
    headTeacherTitle: "প্রধান শিক্ষক",
    classTeacherTitle: "শ্রেণি শিক্ষক",
    borderStyle: "gold",
    sealType: "govt",
    showWatermark: true,
    showQrCode: false,
    showOfficialStamp: false,
    fontSize: "base",
    orientation: "landscape",
  });

  const [isSavingCert, setIsSavingCert] = useState(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3500);
  };

  // Fetch initial settings, students, and certificates
  const fetchData = async () => {
    try {
      // 1. Settings
      const setRes = await fetch("/api/settings");
      const setData = await setRes.json();
      if (setData.success && setData.data) {
        setSettings(setData.data);
      }

      // 2. Students
      const stuRes = await fetch("/api/students");
      const stuData = await stuRes.json();
      if (stuData.success && stuData.data) {
        setStudents(stuData.data);
        setFilteredStudents(stuData.data);

        // Auto select first student or Nur Alam if not selected
        if (!selectedStudent && stuData.data.length > 0) {
          const first = stuData.data[0];
          setSelectedStudent(first);
          loadStudentIntoCertificate(first, setData.data || settings);
        }
      }

      // 3. Certificates history
      const certRes = await fetch("/api/certificates");
      const certData = await certRes.json();
      if (certData.success && certData.data) {
        setCertificatesHistory(certData.data);
      }
    } catch (err) {
      console.error("Fetch data error:", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filter students based on search and class filter
  useEffect(() => {
    let result = [...students];
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (s) =>
          s.nameBn.toLowerCase().includes(q) ||
          (s.nameEn && s.nameEn.toLowerCase().includes(q)) ||
          s.rollNo.includes(q) ||
          s.fatherName.toLowerCase().includes(q) ||
          s.village.toLowerCase().includes(q)
      );
    }
    if (classFilter !== "all") {
      result = result.filter((s) => s.studentClass === classFilter);
    }
    setFilteredStudents(result);
  }, [searchTerm, classFilter, students]);

  // Load a student's data into active certificate state with 1-click
  const loadStudentIntoCertificate = (
    student: Student,
    currentSchoolSettings = settings,
    type = certState.certificateType
  ) => {
    const memo = `${currentSchoolSettings.memoPrefix || "ছাই:পূ:পা/২০২৬/"}${toBengaliDigits(student.rollNo)}`;

    let p1 = "";
    let p2 = "";
    let p3 = "";

    if (type === "প্রশংসাপত্র / ছাড়পত্র") {
      p1 = generateTransferCertificateParagraph({
        studentName: student.nameBn,
        fatherName: student.fatherName,
        motherName: student.motherName,
        studentVillage: student.village,
        studentPostOffice: student.postOffice,
        studentThana: student.thanaUpazila,
        studentDistrict: student.district,
        academicYear: student.academicYear,
        studentClass: student.studentClass,
        gender: student.gender,
        rollNo: student.rollNo,
        dateOfBirth: student.dateOfBirth,
      });
      p2 = "সে অত্র বিদ্যালয়ে অধ্যয়নকালে কোনো নিয়মশৃঙ্খলা বিরোধী আচরণ করেনি। তার চরিত্র উত্তম।";
      p3 = "আমি তাহার ভবিষ্যৎ শিক্ষা ও কর্মজীবনের সাফল্য এবং সর্বাঙ্গীন মঙ্গল কামনা করি।";
    } else if (type === "উপবৃত্তি প্রত্যয়ন পত্র") {
      p1 = generateStipendParagraph({
        studentName: student.nameBn,
        fatherName: student.fatherName,
        motherName: student.motherName,
        academicYear: student.academicYear,
        studentClass: student.studentClass,
        gender: student.gender,
        rollNo: student.rollNo,
        dateOfBirth: student.dateOfBirth,
      });
      p2 = `বিদ্যালয়ের ভর্তি রেকর্ড ও তথ্য অনুযায়ী তার জন্ম তারিখ: ${student.dateOfBirth}। তার পারিবারিক আর্থিক অবস্থা বিবেচনা করে এবং নিয়মিত উপস্থিতির ভিত্তিতে উপবৃত্তি প্রদান করা হয়।`;
      p3 = "তার প্রয়োজনীয় কাজে ব্যবহারের জন্য এই প্রত্যয়ন পত্র প্রদান করা হলো।";
    } else if (type === "জন্ম নিবন্ধন ও বয়স প্রত্যয়ন") {
      p1 = generateAgeParagraph({
        studentName: student.nameBn,
        fatherName: student.fatherName,
        motherName: student.motherName,
        dateOfBirth: student.dateOfBirth,
        birthRegNo: student.birthRegNo || undefined,
        studentClass: student.studentClass,
      });
      p2 = `বিদ্যালয়ের মূল ভর্তি রেজিস্টার এবং পিতা-মাতার জাতীয় পরিচয়পত্র অনুযায়ী তার উল্লেখিত বয়স ও জন্ম তারিখ সম্পূর্ণ সঠিক।`;
      p3 = "তার পিতা-মাতার আবেদনের প্রেক্ষিতে প্রয়োজনীয় কাজের জন্য অত্র প্রত্যয়ন পত্র প্রদান করা হলো।";
    } else {
      // Default: প্রত্যয়ন পত্র matching the exact format of the image provided!
      p1 = generateDefaultParagraph1({
        studentName: student.nameBn,
        fatherName: student.fatherName,
        motherName: student.motherName,
        studentVillage: student.village,
        studentPostOffice: student.postOffice,
        studentThana: student.thanaUpazila,
        studentDistrict: student.district,
        academicYear: student.academicYear,
        studentClass: student.studentClass,
        gender: student.gender,
        rollNo: student.rollNo,
      });
      p2 = generateDefaultParagraph2({
        gender: student.gender,
        characterRemark: student.characterRemark,
        dateOfBirth: student.dateOfBirth,
      });
      p3 = generateDefaultParagraph3();
    }

    setCertState((prev) => ({
      ...prev,
      schoolName: currentSchoolSettings.schoolName,
      establishedYear: currentSchoolSettings.establishedYear,
      village: currentSchoolSettings.village,
      postOffice: currentSchoolSettings.postOffice,
      thanaUpazila: currentSchoolSettings.thanaUpazila,
      district: currentSchoolSettings.district,
      ministryName: currentSchoolSettings.ministryName,
      departmentName: currentSchoolSettings.departmentName,
      directorateName: currentSchoolSettings.directorateName,
      memoNo: memo,
      certificateType: type,
      studentId: student.id,
      studentName: student.nameBn,
      studentNameEn: student.nameEn || "",
      fatherName: student.fatherName,
      motherName: student.motherName,
      studentVillage: student.village,
      studentPostOffice: student.postOffice,
      studentThana: student.thanaUpazila,
      studentDistrict: student.district,
      academicYear: student.academicYear,
      studentClass: student.studentClass,
      rollNo: student.rollNo,
      gender: student.gender,
      dateOfBirth: student.dateOfBirth,
      characterRemark: student.characterRemark,
      paragraph1: p1,
      paragraph2: p2,
      paragraph3: p3,
      headTeacherName: currentSchoolSettings.headTeacherName,
      headTeacherTitle: currentSchoolSettings.headTeacherTitle,
      classTeacherTitle: currentSchoolSettings.classTeacherTitle,
    }));

    setSelectedStudent(student);
  };

  // Change Template Type (1-Click)
  const handleTemplateChange = (type: string) => {
    if (selectedStudent) {
      loadStudentIntoCertificate(selectedStudent, settings, type);
    } else {
      setCertState((prev) => ({
        ...prev,
        certificateType: type,
      }));
    }
  };

  // Save issued certificate copy to database
  const handleSaveCertificateRecord = async () => {
    try {
      setIsSavingCert(true);
      const res = await fetch("/api/certificates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentId: certState.studentId,
          certificateType: certState.certificateType,
          memoNo: certState.memoNo,
          issueDate: certState.issueDate,
          studentName: certState.studentName,
          studentClass: certState.studentClass,
          rollNo: certState.rollNo,
          academicYear: certState.academicYear,
          fatherName: certState.fatherName,
          motherName: certState.motherName,
          village: certState.studentVillage,
          postOffice: certState.studentPostOffice,
          thanaUpazila: certState.studentThana,
          district: certState.studentDistrict,
          bodyText: `${certState.paragraph1}\n\n${certState.paragraph2}\n\n${certState.paragraph3}`,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "সংরক্ষণ করতে ব্যর্থ হয়েছে");
      }

      setCertificatesHistory((prev) => [data.data, ...prev]);
      showToast("প্রত্যয়ন পত্রের রেকর্ড সফলভাবে ডাটাবেজে সংরক্ষিত হয়েছে!");
    } catch (err: any) {
      alert("ত্রুটি: " + err.message);
    } finally {
      setIsSavingCert(false);
    }
  };

  // Delete student
  const handleDeleteStudent = async (id: number, name: string) => {
    if (!confirm(`আপনি কি সত্যিই শিক্ষার্থী "${name}" এর তথ্য মুছে ফেলতে চান?`)) {
      return;
    }
    try {
      const res = await fetch(`/api/students/${id}`, { method: "DELETE" });
      if (res.ok) {
        setStudents((prev) => prev.filter((s) => s.id !== id));
        showToast(`শিক্ষার্থী "${name}" এর তথ্য মুছে ফেলা হয়েছে।`);
      }
    } catch (err) {
      alert("মুছতে ব্যর্থ হয়েছে");
    }
  };

  // 1-Click: From student row directly generate certificate and switch to certificate tab
  const handleQuickGenerateFromRow = (student: Student) => {
    loadStudentIntoCertificate(student, settings, "প্রত্যয়ন পত্র");
    setActiveTab("certificate");
    showToast(`"${student.nameBn}" এর প্রত্যয়ন পত্র তৈরি করা হয়েছে!`);
  };

  // When school settings are updated
  const handleSettingsSaved = (updated: SchoolSettings) => {
    setSettings(updated);
    setCertState((prev) => ({
      ...prev,
      schoolName: updated.schoolName,
      establishedYear: updated.establishedYear,
      village: updated.village,
      postOffice: updated.postOffice,
      thanaUpazila: updated.thanaUpazila,
      district: updated.district,
      ministryName: updated.ministryName,
      departmentName: updated.departmentName,
      directorateName: updated.directorateName,
      headTeacherName: updated.headTeacherName,
      headTeacherTitle: updated.headTeacherTitle,
      classTeacherTitle: updated.classTeacherTitle,
    }));
    showToast("বিদ্যালয়ের তথ্য আপডেট করা হয়েছে!");
  };

  // When student is added/saved
  const handleStudentSaved = (student: Student, generateNow = false) => {
    setStudents((prev) => {
      const index = prev.findIndex((s) => s.id === student.id);
      if (index >= 0) {
        const next = [...prev];
        next[index] = student;
        return next;
      }
      return [student, ...prev];
    });

    if (generateNow) {
      loadStudentIntoCertificate(student, settings, "প্রত্যয়ন পত্র");
      setActiveTab("certificate");
      showToast(`শিক্ষার্থী "${student.nameBn}" এর প্রত্যয়ন পত্র তৈরি হয়েছে!`);
    } else {
      showToast(`শিক্ষার্থী "${student.nameBn}" এর তথ্য সংরক্ষিত হয়েছে!`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-sm border border-slate-700 animate-fade-in">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Application Bar */}
      <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
          {/* Brand & School Details */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center font-bold shadow-sm">
              <School className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base md:text-lg text-slate-900 leading-tight">
                  {settings.schoolName}
                </h1>
                <span className="text-[11px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  সক্রিয়
                </span>
              </div>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <span>গ্রাম: {settings.village}</span>
                <span>•</span>
                <span>ডাকঘর: {settings.postOffice}</span>
                <span>•</span>
                <span>উপজেলা: {settings.thanaUpazila}</span>
                <span>•</span>
                <span>জেলা: {settings.district}</span>
              </p>
            </div>
          </div>

          {/* Quick Buttons & Settings */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Android App Button */}
            <button
              onClick={() => setIsAndroidModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold rounded-lg shadow-sm transition-transform active:scale-95 cursor-pointer ring-2 ring-emerald-300/40"
              title="অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন বা APK প্রজেক্ট ডাউনলোড করুন"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-200 animate-pulse" />
              <span>📲 অ্যান্ড্রয়েড অ্যাপ</span>
            </button>

            {/* Direct Link to Standalone HTML file */}
            <a
              href="/certificate.html"
              download="প্রত্যয়ন_পত্র_এডিটেবল.html"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
              title="সম্পূর্ণ স্বাধীন অফলাইন .HTML ফাইল ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5 text-emerald-200" />
              <span className="hidden sm:inline">.HTML ফাইল</span>
              <span className="sm:hidden">.HTML</span>
            </a>

            <a
              href="/certificate.html"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition-colors cursor-pointer hidden md:inline-flex"
              title="নতুন ট্যাবে ফুলস্ক্রিন .HTML ফাইল ওপেন করুন"
            >
              <span>🌐 .HTML ভিউ</span>
            </a>

            <button
              onClick={() => setIsSettingsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition-colors cursor-pointer"
              title="বিদ্যালয়ের নাম, ঠিকানা ও সিল সেটিংস"
            >
              <Settings className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">স্কুল সেটিংস</span>
            </button>

            <button
              onClick={() => {
                setStudentToEdit(null);
                setIsStudentModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5 text-blue-200" />
              <span>নতুন শিক্ষার্থী</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 border-t border-slate-100 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab("certificate")}
            className={`inline-flex items-center gap-2 py-2.5 px-4 border-b-2 transition-all cursor-pointer ${
              activeTab === "certificate"
                ? "border-blue-700 text-blue-700 bg-blue-50/40"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>প্রত্যয়ন পত্র ও লাইভ এডিটর</span>
          </button>

          <button
            onClick={() => setActiveTab("students")}
            className={`inline-flex items-center gap-2 py-2.5 px-4 border-b-2 transition-all cursor-pointer ${
              activeTab === "students"
                ? "border-blue-700 text-blue-700 bg-blue-50/40"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            <Users className="w-4 h-4" />
            <span>শিক্ষার্থী ডাটাবেজ ({students.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("history")}
            className={`inline-flex items-center gap-2 py-2.5 px-4 border-b-2 transition-all cursor-pointer ${
              activeTab === "history"
                ? "border-blue-700 text-blue-700 bg-blue-50/40"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            <History className="w-4 h-4" />
            <span>ইস্যুকৃত রেকর্ড ({certificatesHistory.length})</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 md:p-6">
        {/* ================= TAB 1: CERTIFICATE & LIVE EDITOR ================= */}
        {activeTab === "certificate" && (
          <div className="space-y-4">
            {/* Top Quick Bar: 1-Click Student & Template Selection */}
            <div className="no-print bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
              {/* Student Quick Switcher */}
              <div className="flex items-center gap-2 flex-1 min-w-[280px]">
                <label className="text-xs font-bold text-slate-700 whitespace-nowrap flex items-center gap-1">
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  <span>শিক্ষার্থী নির্বাচন (১-ক্লিক):</span>
                </label>
                <select
                  value={selectedStudent?.id || ""}
                  onChange={(e) => {
                    const st = students.find((s) => s.id === Number(e.target.value));
                    if (st) {
                      loadStudentIntoCertificate(st, settings, certState.certificateType);
                      showToast(`"${st.nameBn}" এর তথ্য লোড করা হয়েছে`);
                    }
                  }}
                  className="flex-1 text-xs font-semibold bg-blue-50/70 border border-blue-200 rounded-lg px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {students.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.nameBn} — শ্রেণি: {st.studentClass}, রোল: {st.rollNo} ({st.gender})
                    </option>
                  ))}
                </select>
              </div>

              {/* Template Picker */}
              <div className="flex items-center gap-2">
                <label className="text-xs font-bold text-slate-700 whitespace-nowrap flex items-center gap-1">
                  <Award className="w-4 h-4 text-amber-600" />
                  <span>প্রত্যয়নের ধরন:</span>
                </label>
                <select
                  value={certState.certificateType}
                  onChange={(e) => handleTemplateChange(e.target.value)}
                  className="text-xs font-semibold bg-amber-50/70 border border-amber-200 rounded-lg px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <option value="প্রত্যয়ন পত্র">প্রত্যয়ন পত্র (সাধারণ অধ্যয়ন)</option>
                  <option value="প্রশংসাপত্র / ছাড়পত্র">প্রশংসাপত্র / ছাড়পত্র</option>
                  <option value="উপবৃত্তি প্রত্যয়ন পত্র">উপবৃত্তি প্রত্যয়ন পত্র</option>
                  <option value="জন্ম নিবন্ধন ও বয়স প্রত্যয়ন">জন্ম নিবন্ধন ও বয়স প্রত্যয়ন</option>
                </select>
              </div>

              {/* Fast New Student Button */}
              <button
                onClick={() => {
                  setStudentToEdit(null);
                  setIsStudentModalOpen(true);
                }}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />
                <span>নতুন ছাত্র এন্ট্রি</span>
              </button>
            </div>

            {/* The Interactive WYSIWYG Certificate View */}
            <CertificateView
              state={certState}
              onChange={(newState) => setCertState(newState)}
              onSaveToDatabase={handleSaveCertificateRecord}
              isSaving={isSavingCert}
            />
          </div>
        )}

        {/* ================= TAB 2: STUDENTS DATABASE & ACTIONS ================= */}
        {activeTab === "students" && (
          <div className="space-y-4">
            {/* Header & Filter Controls */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span>শিক্ষার্থী ডাটাবেজ তালিকা</span>
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-mono">
                    মোট: {students.length} জন
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  যেকোনো শিক্ষার্থীর নামের পাশে &apos;১-ক্লিকে প্রত্যয়ন তৈরি&apos; বোতামে চাপ দিলে সাথে সাথে প্রস্তুত হবে
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setIsBatchModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-300" />
                  <span>একসাথে অনেকের প্রত্যয়ন প্রিন্ট</span>
                </button>

                <button
                  onClick={() => {
                    setStudentToEdit(null);
                    setIsStudentModalOpen(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4 text-blue-200" />
                  <span>নতুন শিক্ষার্থী যোগ করুন</span>
                </button>
              </div>
            </div>

            {/* Search & Filter Bar */}
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="নাম, রোল, পিতার নাম বা গ্রাম দিয়ে খুঁজুন..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={classFilter}
                  onChange={(e) => setClassFilter(e.target.value)}
                  className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 bg-white font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">সকল শ্রেণি</option>
                  <option value="পঞ্চম">পঞ্চম শ্রেণি</option>
                  <option value="চতুর্থ">চতুর্থ শ্রেণি</option>
                  <option value="তৃতীয়">তৃতীয় শ্রেণি</option>
                  <option value="দ্বিতীয়">দ্বিতীয় শ্রেণি</option>
                  <option value="প্রথম">প্রথম শ্রেণি</option>
                  <option value="শিশু শ্রেণি">শিশু শ্রেণি</option>
                </select>
              </div>
            </div>

            {/* Students Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-3 w-14 text-center">রোল</th>
                      <th className="py-3 px-4">শিক্ষার্থীর নাম</th>
                      <th className="py-3 px-3">শ্রেণি</th>
                      <th className="py-3 px-3">লিঙ্গ</th>
                      <th className="py-3 px-4">পিতা ও মাতা</th>
                      <th className="py-3 px-3">জন্ম তারিখ</th>
                      <th className="py-3 px-4">গ্রাম ও ডাকঘর</th>
                      <th className="py-3 px-4 text-center">প্রত্যয়ন পত্র তৈরি</th>
                      <th className="py-3 px-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredStudents.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-10 text-center text-slate-500">
                          কোনো শিক্ষার্থীর তথ্য পাওয়া যায়নি।
                        </td>
                      </tr>
                    ) : (
                      filteredStudents.map((st) => (
                        <tr
                          key={st.id}
                          className="hover:bg-blue-50/40 transition-colors group"
                        >
                          <td className="py-3 px-3 text-center font-bold text-slate-900 font-mono text-sm">
                            {st.rollNo}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900 text-sm">{st.nameBn}</div>
                            {st.nameEn && (
                              <div className="text-[11px] text-slate-500">{st.nameEn}</div>
                            )}
                          </td>
                          <td className="py-3 px-3 font-semibold text-slate-800">
                            {st.studentClass}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                st.gender === "ছাত্রী"
                                  ? "bg-pink-100 text-pink-700"
                                  : "bg-blue-100 text-blue-700"
                              }`}
                            >
                              {st.gender}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-700">
                            <div>পিতা: {st.fatherName}</div>
                            <div className="text-[11px] text-slate-500">মাতা: {st.motherName}</div>
                          </td>
                          <td className="py-3 px-3 text-slate-700 font-mono">
                            {st.dateOfBirth}
                          </td>
                          <td className="py-3 px-4 text-slate-600">
                            <div>{st.village}</div>
                            <div className="text-[11px] text-slate-500">পো: {st.postOffice}</div>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => handleQuickGenerateFromRow(st)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-bold text-xs shadow-xs transition-transform active:scale-95 cursor-pointer"
                              title="এই শিক্ষার্থীর তথ্য দিয়ে প্রত্যয়ন তৈরি করুন"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                              <span>১-ক্লিকে প্রত্যয়ন</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                          <td className="py-3 px-3 text-right">
                            <div className="inline-flex items-center gap-1">
                              <button
                                onClick={() => {
                                  setStudentToEdit(st);
                                  setIsStudentModalOpen(true);
                                }}
                                className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                                title="এডিট করুন"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteStudent(st.id, st.nameBn)}
                                className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: ISSUED CERTIFICATES HISTORY ================= */}
        {activeTab === "history" && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <History className="w-5 h-5 text-indigo-600" />
                  <span>ইস্যুকৃত প্রত্যয়ন পত্রের হিস্ট্রি ও ডাটাবেজ রেকর্ড</span>
                  <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full font-mono">
                    {certificatesHistory.length} টি
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  যেসব প্রত্যয়ন পত্র সেভ করা হয়েছে তাদের তালিকা
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-3">তারিখ</th>
                      <th className="py-3 px-3">স্মারক নং</th>
                      <th className="py-3 px-4">শিক্ষার্থীর নাম</th>
                      <th className="py-3 px-3">শ্রেণি ও রোল</th>
                      <th className="py-3 px-3">ধরন</th>
                      <th className="py-3 px-4">পিতার নাম ও গ্রাম</th>
                      <th className="py-3 px-3 text-right">পুনরায় দেখুন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {certificatesHistory.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-500">
                          এখনো কোনো প্রত্যয়ন পত্র সেভ করা হয়নি।
                        </td>
                      </tr>
                    ) : (
                      certificatesHistory.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-3 text-slate-700 font-mono">
                            {item.issueDate}
                          </td>
                          <td className="py-3 px-3 font-mono font-medium text-slate-800">
                            {item.memoNo}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">
                            {item.studentName}
                          </td>
                          <td className="py-3 px-3 text-slate-700">
                            {item.studentClass} (রোল: {item.rollNo})
                          </td>
                          <td className="py-3 px-3">
                            <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-semibold text-[10.5px]">
                              {item.certificateType}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-600">
                            {item.fatherName}, {item.village}
                          </td>
                          <td className="py-3 px-3 text-right">
                            <button
                              onClick={() => {
                                setCertState((prev) => ({
                                  ...prev,
                                  memoNo: item.memoNo,
                                  issueDate: item.issueDate,
                                  studentName: item.studentName,
                                  studentClass: item.studentClass,
                                  rollNo: item.rollNo,
                                  certificateType: item.certificateType,
                                  fatherName: item.fatherName || "",
                                  studentVillage: item.village || "ছাইহাটা",
                                  studentPostOffice: item.postOffice || "নিউ সোনাতলা",
                                  studentThana: item.thanaUpazila || "সারিয়াকান্দি",
                                  studentDistrict: item.district || "বগুড়া",
                                }));
                                setActiveTab("certificate");
                                showToast(`"${item.studentName}" এর সংরক্ষিত প্রত্যয়ন খোলা হয়েছে`);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-md transition-colors cursor-pointer"
                            >
                              <span>দেখুন</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Student Add/Edit Modal */}
      <StudentModal
        isOpen={isStudentModalOpen}
        onClose={() => {
          setIsStudentModalOpen(false);
          setStudentToEdit(null);
        }}
        onSaved={handleStudentSaved}
        initialData={studentToEdit}
        defaultVillage={settings.village}
        defaultPostOffice={settings.postOffice}
        defaultThana={settings.thanaUpazila}
        defaultDistrict={settings.district}
      />

      {/* School Settings Modal */}
      <SchoolSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaved={handleSettingsSaved}
      />

      {/* Batch Print Modal */}
      <BatchPrintModal
        isOpen={isBatchModalOpen}
        onClose={() => setIsBatchModalOpen(false)}
        students={students}
        settings={settings}
      />

      {/* Android App Modal */}
      <AndroidAppModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      {/* Mobile Floating Action Bottom Bar for Android */}
      <div className="no-print md:hidden fixed bottom-3 left-3 right-3 z-40 bg-slate-900/95 backdrop-blur-md text-white p-2 rounded-2xl shadow-2xl flex items-center justify-around border border-slate-700">
        <button
          onClick={() => setActiveTab("certificate")}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold py-1 px-2.5 rounded-xl transition-colors ${
            activeTab === "certificate" ? "bg-blue-600 text-white" : "text-slate-400"
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>প্রত্যয়ন</span>
        </button>

        <button
          onClick={() => setActiveTab("students")}
          className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold py-1 px-2.5 rounded-xl transition-colors ${
            activeTab === "students" ? "bg-blue-600 text-white" : "text-slate-400"
          }`}
        >
          <Users className="w-4 h-4" />
          <span>ছাত্রতালিকা</span>
        </button>

        <button
          onClick={() => {
            setStudentToEdit(null);
            setIsStudentModalOpen(true);
          }}
          className="flex flex-col items-center gap-0.5 text-[10px] font-semibold py-1 px-2.5 rounded-xl text-amber-300"
        >
          <PlusCircle className="w-4 h-4" />
          <span>এন্ট্রি</span>
        </button>

        <button
          onClick={() => window.print()}
          className="flex flex-col items-center gap-0.5 text-[10px] font-semibold py-1 px-2.5 rounded-xl text-slate-300"
        >
          <Printer className="w-4 h-4" />
          <span>প্রিন্ট</span>
        </button>

        <button
          onClick={() => setIsAndroidModalOpen(true)}
          className="flex flex-col items-center gap-0.5 text-[10px] font-bold py-1 px-2 rounded-xl bg-emerald-600 text-white animate-pulse"
        >
          <Smartphone className="w-4 h-4 text-emerald-200" />
          <span>অ্যাপ</span>
        </button>
      </div>

      {/* Footer */}
      <footer className="no-print mt-auto bg-white border-t border-slate-200 py-3 text-center text-xs text-slate-500">
        <p>
          {settings.schoolName} — গ্রাম: {settings.village}, ডাকঘর: {settings.postOffice}, উপজেলা: {settings.thanaUpazila}, জেলা: {settings.district} | প্রাথমিক শিক্ষা অধিদপ্তর
        </p>
      </footer>
    </div>
  );
}
