"use client";

import React, { useState, useEffect } from "react";
import {
  Smartphone,
  Download,
  X,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  Layers,
  ArrowRight,
  ShieldCheck,
  WifiOff,
  Code2,
  Printer,
  Copy,
  Check,
} from "lucide-react";

interface AndroidAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AndroidAppModal({ isOpen, onClose }: AndroidAppModalProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState<"install" | "apk" | "offline">("install");

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      alert(
        "আপনার অ্যান্ড্রয়েড ফোনের Chrome ব্রাউজারের উপরে ডানদিকের তিনটি ডট (⋮) মেনুতে ক্লিক করে 'Install App' অথবা 'Add to Home screen' (হোম স্ক্রিনে যোগ করুন) চাপুন। এর ফলে অ্যাপটি ইনস্টল হয়ে ফোনের হোম স্ক্রিনে আইকন চলে আসবে!"
      );
    }
  };

  const handleDownloadAndroidZip = async () => {
    try {
      setIsDownloading(true);
      const res = await fetch("/api/download-android-project");
      if (!res.ok) throw new Error("Failed to download");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "chaihata-prottayon-android-app-project.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      alert("ডাউনলোড করতে সমস্যা হয়েছে");
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyAppUrl = () => {
    const url = window.location.origin;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 via-blue-800 to-indigo-900 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Smartphone className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base md:text-lg flex items-center gap-1.5">
                <span>অ্যান্ড্রয়েড অ্যাপ (Android App)</span>
                <span className="text-[10px] bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 px-2 py-0.5 rounded-full font-mono">
                  APK / PWA
                </span>
              </h3>
              <p className="text-xs text-blue-100">
                ছাইহাটা প্রাথমিক বিদ্যালয় — শিক্ষার্থীদের প্রত্যয়ন পত্র জেনারেটর
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center border-b border-slate-200 bg-slate-50 px-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab("install")}
            className={`py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === "install"
                ? "border-blue-700 text-blue-700 font-bold bg-white"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            📲 ফোনে সরাসরি অ্যাপ ইনস্টল
          </button>

          <button
            onClick={() => setActiveTab("apk")}
            className={`py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === "apk"
                ? "border-blue-700 text-blue-700 font-bold bg-white"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            📦 Android APK / Studio Project
          </button>

          <button
            onClick={() => setActiveTab("offline")}
            className={`py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === "offline"
                ? "border-blue-700 text-blue-700 font-bold bg-white"
                : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            📶 অফলাইনে ব্যবহার
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 md:p-6 overflow-y-auto space-y-4">
          {/* TAB 1: Direct PWA Install on Android */}
          {activeTab === "install" && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm text-emerald-900">
                    অ্যান্ড্রয়েড ফোনে সরাসরি ইনস্টল করার সবচেয়ে সহজ পদ্ধতি:
                  </h4>
                  <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                    এটি একটি আধুনিক <strong>PWA (Progressive Web App)</strong>। আলাদা কোনো প্লে-স্টোর ছাড়াই আপনার ফোনে সরাসরি অ্যাপ হিসেবে ইনস্টল হবে এবং হোম স্ক্রিনে অ্যাপ আইকন তৈরি হবে।
                  </p>
                </div>
              </div>

              {/* Install Action Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center shadow-md shrink-0">
                    <Smartphone className="w-8 h-8 text-amber-300" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 text-sm">
                      প্রত্যয়ন পত্র — ছাইহাটা প্রাথমিক বিদ্যালয়
                    </h5>
                    <p className="text-xs text-slate-500 mt-0.5">
                      ভার্সন ১.০ • সাইজ মাত্র ৫০০ KB • অফলাইন সাপোর্ট
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                        Android 6.0+
                      </span>
                      <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                        সম্পূর্ণ ফ্রি
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleInstallPwa}
                  className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isInstalled ? "অ্যাপটি ইনস্টল রয়েছে" : "১-ক্লিকে ফোনে ইনস্টল করুন"}</span>
                </button>
              </div>

              {/* Step by step manual guide */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-3">
                <h5 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
                  ম্যানুয়াল ইনস্টল পদ্ধতি (যেকোনো ফোনে):
                </h5>
                <ol className="text-xs text-slate-600 space-y-2 list-decimal pl-4 leading-relaxed">
                  <li>
                    অ্যান্ড্রয়েড ফোনে Chrome বা Samsung Internet ব্রাউজারে এই ওয়েবসাইটটি ওপেন করুন।
                  </li>
                  <li>
                    ব্রাউজারের উপরের ডানদিকের <strong>তিনটি ডট (⋮) মেনু</strong> বোতামে চাপ দিন।
                  </li>
                  <li>
                    মেনু তালিকা থেকে <strong>&quot;Install app&quot;</strong> অথবা <strong>&quot;Add to Home screen&quot; (হোম স্ক্রিনে যোগ করুন)</strong> নির্বাচন করুন।
                  </li>
                  <li>
                    <strong>&quot;Install&quot;</strong> বাটনে চাপলেই কয়েক সেকেন্ডে ফোনের হোম স্ক্রিনে অ্যাপ আইকন তৈরি হয়ে যাবে!
                  </li>
                </ol>

                <div className="pt-2 flex items-center justify-between border-t border-slate-200">
                  <span className="text-xs text-slate-500">ফোনে লিংক পাঠানোর জন্য লিংক কপি করুন:</span>
                  <button
                    onClick={handleCopyAppUrl}
                    className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-md border border-slate-300 transition-colors cursor-pointer"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? "কপি হয়েছে!" : "অ্যাপের লিংক কপি"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Android Studio Project & APK Generation */}
          {activeTab === "apk" && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <h4 className="font-bold text-sm text-blue-950 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-blue-700" />
                  <span>সম্পূর্ণ অ্যান্ড্রয়েড স্টুডিও প্রজেক্ট (.ZIP)</span>
                </h4>
                <p className="text-xs text-blue-900 mt-1 leading-relaxed">
                  আমরা সম্পূর্ণ সোর্স কোড (Java, AndroidManifest, Gradle, Layouts, Assets) প্রস্তুত করে দিয়েছি। এটি দিয়ে সরাসরি Android Studio অথবা যেকোনো APK কনভার্টার থেকে ইনস্টলযোগ্য <strong>.APK</strong> ফাইল বানাতে পারবেন।
                </p>
              </div>

              {/* Download Project Card */}
              <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-sm text-amber-300">
                    chaihata-prottayon-android-app-project.zip
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    MainActivity.java • AndroidManifest.xml • Native PrintManager Support
                  </p>
                </div>

                <button
                  onClick={handleDownloadAndroidZip}
                  disabled={isDownloading}
                  className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow-sm transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>{isDownloading ? "প্রস্তুত হচ্ছে..." : "Android Project (.zip) ডাউনলোড"}</span>
                </button>
              </div>

              {/* Instructions on how to build APK */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-2.5 text-xs text-slate-700">
                <h5 className="font-bold text-slate-900">
                  কিভাবে Android Studio দিয়ে .APK তৈরি করবেন:
                </h5>
                <p>1. জিপ ফাইলটি ডাউনলোড করে আনজিপ করুন।</p>
                <p>2. Android Studio ওপেন করে <strong>Open an Existing Project</strong> দিয়ে ফোল্ডারটি ওপেন করুন।</p>
                <p>3. গ্রেডল সিঙ্ক শেষ হলে মেনু থেকে <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> চাপুন।</p>
                <p>4. আউটপুট ফোল্ডারে আপনার কাঙ্ক্ষিত <strong>app-debug.apk</strong> ফাইল পেয়ে যাবেন যা যেকোনো ফোনে ইন্সটল করা যায়।</p>
              </div>
            </div>
          )}

          {/* TAB 3: Offline Features */}
          {activeTab === "offline" && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
                <WifiOff className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm text-amber-900">
                    ইন্টারনেট ছাড়াই ১০০% অফলাইনে ব্যবহারের সুবিধা
                  </h4>
                  <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                    গ্রামাঞ্চলে (যেমন: ছাইহাটা গ্রামে) অনেক সময় মোবাইল নেটওয়ার্ক ধীরগতির থাকে। এই অ্যাপটি সম্পূর্ণ অফলাইন-রেডি করা হয়েছে!
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>অফলাইন লোকাল ডাটাবেজ</span>
                  </div>
                  <p className="text-slate-600">
                    ফোনে ডাটা অন না থাকলেও পূর্বে এন্ট্রি করা শিক্ষার্থীদের তথ্য ও স্কুলের নাম ফোনে সংরক্ষিত থাকবে।
                  </p>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <div className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                    <Printer className="w-4 h-4 text-blue-600" />
                    <span>সরাসরি ফোন থেকে প্রিন্ট ও PDF</span>
                  </div>
                  <p className="text-slate-600">
                    মোবাইলে OTG কেবল বা ওয়াইফাই প্রিন্টারের মাধ্যমে অথবা সরাসরি <strong>Save as PDF</strong> করে সেভ রাখা যায়।
                  </p>
                </div>
              </div>

              {/* Offline standalone HTML link */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-slate-900">
                    স্বাধীন অফলাইন .HTML ফাইল ডাউনলোড করতে চান?
                  </div>
                  <p className="text-[11px] text-slate-500">
                    যেকোনো কম্পিউটারে বা ফোনে ইন্টারনেট ছাড়া ডাবল ক্লিকে চলবে।
                  </p>
                </div>
                <a
                  href="/certificate.html"
                  download="প্রত্যয়ন_পত্র_এডিটেবল.html"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>.HTML ডাউনলোড</span>
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
}
