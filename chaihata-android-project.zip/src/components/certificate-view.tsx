"use client";

import React, { useRef, useState, useEffect } from "react";
import { BdSealSvg, BdNationalEmblemSvg } from "./bd-seal";
import { CertificateQrCode } from "./qr-code";
import {
  Printer,
  Download,
  Copy,
  Check,
  Save,
  RotateCcw,
  Sparkles,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Sliders,
  FileText,
  UserCheck,
  CheckCircle2,
  Code2,
  Eye,
  Stamp,
} from "lucide-react";
import {
  buildStandaloneEditableHtml,
  toBengaliDigits,
  toEnglishDigits,
  getTodayDateBengali,
  getTodayDateEnglish,
} from "@/lib/bangla-utils";

export interface CertificateState {
  schoolName: string;
  establishedYear: string;
  village: string;
  postOffice: string;
  thanaUpazila: string;
  district: string;
  ministryName: string;
  departmentName: string;
  directorateName: string;
  memoNo: string;
  issueDate: string;
  certificateType: string;
  // Student specific
  studentId?: number;
  studentName: string;
  studentNameEn?: string;
  fatherName: string;
  motherName: string;
  studentVillage: string;
  studentPostOffice: string;
  studentThana: string;
  studentDistrict: string;
  academicYear: string;
  studentClass: string;
  rollNo: string;
  gender: string;
  dateOfBirth: string;
  birthRegNo?: string;
  characterRemark?: string;
  // Text blocks
  paragraph1: string;
  paragraph2: string;
  paragraph3: string;
  // Signature & footer
  headTeacherName: string;
  headTeacherTitle: string;
  classTeacherTitle: string;
  // Styling
  borderStyle: "gold" | "navy" | "green" | "maroon";
  sealType: "govt" | "emblem";
  showWatermark: boolean;
  showQrCode: boolean;
  showOfficialStamp: boolean;
  fontSize: "sm" | "base" | "lg";
  orientation: "landscape" | "portrait";
}

interface CertificateViewProps {
  state: CertificateState;
  onChange: (newState: CertificateState) => void;
  onSaveToDatabase?: () => Promise<void>;
  isSaving?: boolean;
}

export function CertificateView({
  state,
  onChange,
  onSaveToDatabase,
  isSaving = false,
}: CertificateViewProps) {
  const certRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [showStylePanel, setShowStylePanel] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [rawHtmlCode, setRawHtmlCode] = useState("");

  // Auto-adjust zoom scale on smaller screens
  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth < 640) {
        setZoomScale(0.46);
      } else if (screenWidth < 1024) {
        setZoomScale(0.70);
      } else if (screenWidth < 1280) {
        setZoomScale(0.85);
      } else {
        setZoomScale(1);
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleFieldChange = (field: keyof CertificateState, value: any) => {
    onChange({
      ...state,
      [field]: value,
    });
  };

  // 1-Click Print
  const handlePrint = () => {
    window.print();
  };

  // Generate HTML string
  const getCompiledHtml = () => {
    return buildStandaloneEditableHtml({
      schoolName: state.schoolName,
      establishedYear: state.establishedYear,
      village: state.village,
      postOffice: state.postOffice,
      thanaUpazila: state.thanaUpazila,
      district: state.district,
      ministryName: state.ministryName,
      departmentName: state.departmentName,
      directorateName: state.directorateName,
      memoNo: state.memoNo,
      issueDate: state.issueDate,
      certificateType: state.certificateType,
      p1: state.paragraph1,
      p2: state.paragraph2,
      p3: state.paragraph3,
      headTeacherName: state.headTeacherName,
      headTeacherTitle: state.headTeacherTitle,
      classTeacherTitle: state.classTeacherTitle,
      borderStyle: state.borderStyle,
      showWatermark: state.showWatermark,
    });
  };

  // 1-Click Download Standalone Editable HTML File
  const handleDownloadHtml = () => {
    const htmlContent = getCompiledHtml();
    const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const sanitizedName = state.studentName
      ? state.studentName.replace(/\s+/g, "_")
      : "student";
    a.href = url;
    a.download = `প্রত্যয়ন_পত্র_${sanitizedName}_${state.rollNo}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Show HTML Code Modal
  const handleOpenCodeModal = () => {
    setRawHtmlCode(getCompiledHtml());
    setShowCodeModal(true);
  };

  // 1-Click Copy Full Text
  const handleCopyText = () => {
    const fullText = `
${state.schoolName}
${state.certificateType}
স্মারক নং : ${state.memoNo}  |  তারিখ: ${state.issueDate}

${state.paragraph1.replace(/<[^>]+>/g, "")}

${state.paragraph2.replace(/<[^>]+>/g, "")}

${state.paragraph3.replace(/<[^>]+>/g, "")}

${state.classTeacherTitle}                     ${state.headTeacherTitle} (${state.headTeacherName})
    `.trim();

    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // 1-Click Save Record
  const handleSave = async () => {
    if (onSaveToDatabase) {
      await onSaveToDatabase();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  // 1-Click Convert all digits to Bengali
  const handleConvertToBengaliDigits = () => {
    onChange({
      ...state,
      rollNo: toBengaliDigits(state.rollNo),
      academicYear: toBengaliDigits(state.academicYear),
      dateOfBirth: toBengaliDigits(state.dateOfBirth),
      establishedYear: toBengaliDigits(state.establishedYear),
      memoNo: toBengaliDigits(state.memoNo),
      issueDate: toBengaliDigits(state.issueDate),
      paragraph1: toBengaliDigits(state.paragraph1),
      paragraph2: toBengaliDigits(state.paragraph2),
      paragraph3: toBengaliDigits(state.paragraph3),
    });
  };

  // 1-Click Today's Bengali Date
  const handleSetTodayBanglaDate = () => {
    onChange({
      ...state,
      issueDate: getTodayDateBengali(),
    });
  };

  // Border styles
  const borderColors = {
    gold: {
      outer: "#b8860b",
      inner: "#c59b27",
      badgeBg: "bg-[#1e56a0] hover:bg-[#1a4a8a]",
    },
    navy: {
      outer: "#1e3a8a",
      inner: "#2563eb",
      badgeBg: "bg-[#1e3a8a] hover:bg-[#172554]",
    },
    green: {
      outer: "#14532d",
      inner: "#15803d",
      badgeBg: "bg-[#14532d] hover:bg-[#052e16]",
    },
    maroon: {
      outer: "#881337",
      inner: "#9f1239",
      badgeBg: "bg-[#881337] hover:bg-[#4c0519]",
    },
  };

  const currentTheme = borderColors[state.borderStyle] || borderColors.gold;

  // Font size classes
  const fontSizes = {
    sm: {
      body: "text-[15px] leading-[2.0]",
      schoolTitle: "text-[25px]",
      sub: "text-[13px]",
      badge: "text-[16px] px-6 py-0.5",
    },
    base: {
      body: "text-[17px] leading-[2.15]",
      schoolTitle: "text-[28px]",
      sub: "text-[14px]",
      badge: "text-[18px] px-7 py-1",
    },
    lg: {
      body: "text-[19px] leading-[2.25]",
      schoolTitle: "text-[32px]",
      sub: "text-[15.5px]",
      badge: "text-[20px] px-8 py-1",
    },
  };

  const currentFont = fontSizes[state.fontSize] || fontSizes.base;
  const qrPayload = `প্রত্যয়ন পত্র | ${state.schoolName} | শিক্ষার্থী: ${state.studentName} | রোল: ${state.rollNo} | শ্রেণি: ${state.studentClass} | তারিখ: ${state.issueDate}`;

  return (
    <div className="flex flex-col items-center w-full">
      {/* Action Toolbar */}
      <div className="no-print w-full max-w-6xl mb-4 bg-white border border-slate-200 rounded-xl p-3 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Quick Actions (1-Click) */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors cursor-pointer"
              title="A4 সাইজে প্রিন্ট বা PDF ডাউনলোড করুন"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট / PDF (১-ক্লিক)</span>
            </button>

            <button
              onClick={handleDownloadHtml}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-sm rounded-lg shadow-sm transition-colors cursor-pointer"
              title="অফলাইনে ব্যবহারের জন্য এডিটেবল HTML ফাইল ডাউনলোড করুন"
            >
              <Download className="w-4 h-4" />
              <span>এডিটেবল HTML ফাইল</span>
            </button>

            <button
              onClick={handleOpenCodeModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm rounded-lg border border-slate-300 transition-colors cursor-pointer"
              title="HTML কোড দেখুন ও কপি করুন"
            >
              <Code2 className="w-4 h-4 text-slate-600" />
              <span>HTML কোড</span>
            </button>

            {onSaveToDatabase && (
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-lg shadow-sm transition-colors disabled:opacity-50 cursor-pointer"
                title="এই প্রত্যয়ন পত্রের কপি ডাটাবেজে সংরক্ষণ করুন"
              >
                {saveSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-green-200" />
                    <span>সংরক্ষিত হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>{isSaving ? "সংরক্ষণ হচ্ছে..." : "রেকর্ড সেভ"}</span>
                  </>
                )}
              </button>
            )}

            <button
              onClick={handleCopyText}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm rounded-lg border border-slate-300 transition-colors cursor-pointer"
              title="সম্পূর্ণ প্রত্যয়ন পত্রের টেক্সট কপি করুন"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-500" />
                  <span>টেক্সট কপি</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Format & Helpers */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleConvertToBengaliDigits}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold rounded-md border border-amber-300 transition-colors cursor-pointer"
              title="সব সংখ্যাকে বাংলায় রূপান্তর করুন (যেমন: 2026 -> ২০২৬)"
            >
              <span>১২৩ বাংলায়</span>
            </button>

            <button
              onClick={handleSetTodayBanglaDate}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-semibold rounded-md border border-blue-300 transition-colors cursor-pointer"
              title="আজকের বাংলা তারিখ সেট করুন"
            >
              <span>আজকের তারিখ</span>
            </button>

            <button
              onClick={() => setShowStylePanel(!showStylePanel)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                showStylePanel
                  ? "bg-slate-800 text-white border-slate-800"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-300"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>ডিজাইন সেটিংস</span>
            </button>

            {/* Zoom Controls */}
            <div className="inline-flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-300">
              <button
                onClick={() => setZoomScale((z) => Math.max(0.4, Number((z - 0.08).toFixed(2))))}
                className="p-1 text-slate-600 hover:text-slate-900 hover:bg-white rounded cursor-pointer"
                title="জুম আউট"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-mono px-1.5 text-slate-600">
                {Math.round(zoomScale * 100)}%
              </span>
              <button
                onClick={() => setZoomScale((z) => Math.min(1.25, Number((z + 0.08).toFixed(2))))}
                className="p-1 text-slate-600 hover:text-slate-900 hover:bg-white rounded cursor-pointer"
                title="জুম ইন"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setZoomScale(1)}
                className="p-1 text-slate-600 hover:text-slate-900 hover:bg-white rounded text-[11px] font-medium px-1 cursor-pointer"
                title="রিসেট ১০০%"
              >
                100%
              </button>
            </div>
          </div>
        </div>

        {/* Collapsible Style Panel */}
        {showStylePanel && (
          <div className="mt-3 pt-3 border-t border-slate-200 grid grid-cols-2 md:grid-cols-6 gap-3 text-xs bg-slate-50 p-2.5 rounded-lg">
            {/* Border Style */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">বর্ডার কালার</label>
              <select
                value={state.borderStyle}
                onChange={(e) => handleFieldChange("borderStyle", e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
              >
                <option value="gold">স্বর্ণালী বর্ডার (Gold - Default)</option>
                <option value="navy">রয়াল ব্লু বর্ডার (Royal Blue)</option>
                <option value="green">জাতীয় সবুজ বর্ডার (Forest Green)</option>
                <option value="maroon">ভিন্টেজ মেরুন বর্ডার (Maroon)</option>
              </select>
            </div>

            {/* Seal Type */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">সরকারী সিল / প্রতীক</label>
              <select
                value={state.sealType}
                onChange={(e) => handleFieldChange("sealType", e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
              >
                <option value="govt">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার সিল</option>
                <option value="emblem">জাতীয় প্রতীক (শাপলা ও ধান)</option>
              </select>
            </div>

            {/* Font Size */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">ফন্ট সাইজ</label>
              <select
                value={state.fontSize}
                onChange={(e) => handleFieldChange("fontSize", e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
              >
                <option value="sm">ছোট (Small - বেশি লেখার জন্য)</option>
                <option value="base">আদর্শ সাইজ (Standard - Default)</option>
                <option value="lg">বড় সাইজ (Large)</option>
              </select>
            </div>

            {/* Watermark Toggle */}
            <div className="flex items-center gap-2 pt-4">
              <input
                type="checkbox"
                id="watermark-toggle"
                checked={state.showWatermark}
                onChange={(e) => handleFieldChange("showWatermark", e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 cursor-pointer"
              />
              <label htmlFor="watermark-toggle" className="font-medium text-slate-700 cursor-pointer">
                জলছাপ (Watermark)
              </label>
            </div>

            {/* QR Code Toggle */}
            <div className="flex items-center gap-2 pt-4">
              <input
                type="checkbox"
                id="qr-toggle"
                checked={state.showQrCode}
                onChange={(e) => handleFieldChange("showQrCode", e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 cursor-pointer"
              />
              <label htmlFor="qr-toggle" className="font-medium text-slate-700 cursor-pointer">
                QR কোড ভেরিফিকেশন
              </label>
            </div>

            {/* Official Stamp Toggle */}
            <div className="flex items-center gap-2 pt-4">
              <input
                type="checkbox"
                id="stamp-toggle"
                checked={state.showOfficialStamp}
                onChange={(e) => handleFieldChange("showOfficialStamp", e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded border-slate-300 cursor-pointer"
              />
              <label htmlFor="stamp-toggle" className="font-medium text-slate-700 cursor-pointer">
                গোল সিল (Official Seal)
              </label>
            </div>
          </div>
        )}

        {/* Live editing hint */}
        <div className="mt-2 text-[12px] text-amber-800 bg-amber-50/80 px-2.5 py-1.5 rounded border border-amber-200/80 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>
              <strong>সরাসরি এডিট সুবিধা:</strong> আপনি সার্টিফিকেটের যেকোনো লেখার উপর সরাসরি ক্লিক করে টাইপ করতে পারেন (স্কুল নাম, রোল, তারিখ ইত্যাদি)!
            </span>
          </span>
          <span className="text-[11px] text-slate-500 font-mono hidden md:inline">A4 Landscape</span>
        </div>
      </div>

      {/* Certificate Sheet Display Box */}
      <div className="w-full flex justify-center overflow-x-auto pb-10 print:p-0 print:overflow-visible">
        <div
          style={{
            transform: `scale(${zoomScale})`,
            transformOrigin: "top center",
            transition: "transform 0.15s ease-out",
          }}
          className="print:transform-none"
        >
          {/* A4 Landscape Document Frame */}
          <div
            ref={certRef}
            className="certificate-sheet relative bg-white text-slate-900 mx-auto select-text shadow-2xl print:shadow-none print:m-0"
            style={{
              width: "297mm",
              minHeight: "208mm",
              height: "208mm",
              boxSizing: "border-box",
              padding: "13mm 16mm",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Outer Golden/Custom Border */}
            <div
              className="absolute pointer-events-none"
              style={{
                top: "5.5mm",
                left: "5.5mm",
                right: "5.5mm",
                bottom: "5.5mm",
                border: `1.8px solid ${currentTheme.outer}`,
              }}
            />

            {/* Inner Thicker Golden/Custom Border */}
            <div
              className="absolute pointer-events-none"
              style={{
                top: "8.5mm",
                left: "8.5mm",
                right: "8.5mm",
                bottom: "8.5mm",
                border: `5px solid ${currentTheme.inner}`,
              }}
            />

            {/* Watermark in background */}
            {state.showWatermark && (
              <div
                className="absolute inset-0 flex items-center justify-center pointer-events-none z-0"
                style={{ opacity: 0.045 }}
              >
                <div className="w-80 h-80 flex items-center justify-center">
                  <BdSealSvg className="w-full h-full text-slate-900" />
                </div>
              </div>
            )}

            {/* Content Container */}
            <div className="relative z-10 h-full flex flex-col justify-between">
              {/* TOP HEADER SECTION */}
              <div>
                {/* Row: Memo No (Left), Seal (Center), Date (Right) */}
                <div className="flex items-start justify-between relative">
                  {/* Memo No */}
                  <div className="w-1/3 pt-1 text-left">
                    <span className="font-bold text-slate-900 text-[16px] inline-flex items-center gap-1">
                      <span>স্মারক নং</span>
                      <span
                        contentEditable
                        suppressContentEditableWarning
                        onBlur={(e) => handleFieldChange("memoNo", e.currentTarget.textContent || "")}
                        className="inline-edit min-w-[90px] border-b border-dotted border-slate-500 font-normal ml-1"
                      >
                        {state.memoNo || "........................"}
                      </span>
                    </span>
                  </div>

                  {/* Center BD Seal */}
                  <div className="w-1/3 flex justify-center -mt-1.5">
                    {state.sealType === "govt" ? (
                      <BdSealSvg className="w-[66px] h-[66px]" />
                    ) : (
                      <BdNationalEmblemSvg className="w-[66px] h-[66px]" />
                    )}
                  </div>

                  {/* Date */}
                  <div className="w-1/3 pt-1 text-right">
                    <span className="font-bold text-slate-900 text-[16px] inline-flex items-center justify-end gap-1">
                      <span>তারিখ:</span>
                      <span
                        contentEditable
                        suppressContentEditableWarning
                        onBlur={(e) => handleFieldChange("issueDate", e.currentTarget.textContent || "")}
                        className="inline-edit min-w-[85px] border-b border-dotted border-slate-500 font-normal ml-1"
                      >
                        {state.issueDate || "২২/১১/২০২৬ খ্রি:"}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Sub headers: Govt / Ministry / Directorate */}
                <div className="text-center mt-0.5 leading-[1.3] text-slate-800 font-medium text-[14.5px]">
                  <div
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={(e) => handleFieldChange("ministryName", e.currentTarget.textContent || "")}
                    className="inline-edit"
                  >
                    {state.ministryName}
                  </div>
                  <div
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={(e) => handleFieldChange("departmentName", e.currentTarget.textContent || "")}
                    className="inline-edit"
                  >
                    {state.departmentName}
                  </div>
                  <div
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={(e) => handleFieldChange("directorateName", e.currentTarget.textContent || "")}
                    className="inline-edit"
                  >
                    {state.directorateName}
                  </div>
                </div>

                {/* School Name (Large & Bold) */}
                <div className="text-center mt-1">
                  <h1
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={(e) => handleFieldChange("schoolName", e.currentTarget.textContent || "")}
                    className={`font-black text-slate-900 tracking-tight inline-edit ${currentFont.schoolTitle}`}
                    style={{ fontFamily: "'Hind Siliguri', 'Noto Serif Bengali', sans-serif" }}
                  >
                    {state.schoolName}
                  </h1>
                </div>

                {/* School Subtitle / Address */}
                <div className="text-center text-slate-700 font-medium mt-0.5 mb-2.5">
                  <span className={`inline-edit text-slate-800 ${currentFont.sub}`}>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("establishedYear", e.currentTarget.textContent?.replace("স্থাপিত: ", "") || "")}
                    >
                      স্থাপিত: {state.establishedYear}
                    </span>
                    <span>, গ্রাম: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("village", e.currentTarget.textContent || "")}
                    >
                      {state.village}
                    </span>
                    <span>, ডাকঘর: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("postOffice", e.currentTarget.textContent || "")}
                    >
                      {state.postOffice}
                    </span>
                    <span>, থানা: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("thanaUpazila", e.currentTarget.textContent || "")}
                    >
                      {state.thanaUpazila}
                    </span>
                    <span>, জেলা: </span>
                    <span
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("district", e.currentTarget.textContent || "")}
                    >
                      {state.district}
                    </span>
                  </span>
                </div>

                {/* Blue Badge: "প্রত্যয়ন পত্র" */}
                <div className="flex justify-center mb-3">
                  <span
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={(e) => handleFieldChange("certificateType", e.currentTarget.textContent || "")}
                    className={`inline-block ${currentTheme.badgeBg} text-white font-bold rounded-sm tracking-wide shadow-sm cursor-text transition-colors ${currentFont.badge}`}
                  >
                    {state.certificateType}
                  </span>
                </div>
              </div>

              {/* CERTIFICATE BODY SECTION */}
              <div className={`flex-1 flex flex-col justify-center px-4 md:px-8 text-slate-900 text-justify ${currentFont.body}`}>
                {/* Paragraph 1 */}
                <div
                  contentEditable
                  suppressContentEditableWarning
                  onBlur={(e) => handleFieldChange("paragraph1", e.currentTarget.innerHTML || "")}
                  dangerouslySetInnerHTML={{ __html: state.paragraph1 }}
                  className="inline-edit mb-3.5"
                />

                {/* Paragraph 2 */}
                <div
                  contentEditable
                  suppressContentEditableWarning
                  onBlur={(e) => handleFieldChange("paragraph2", e.currentTarget.innerHTML || "")}
                  dangerouslySetInnerHTML={{ __html: state.paragraph2 }}
                  className="inline-edit mb-3.5"
                />

                {/* Paragraph 3 */}
                <div
                  contentEditable
                  suppressContentEditableWarning
                  onBlur={(e) => handleFieldChange("paragraph3", e.currentTarget.innerHTML || "")}
                  dangerouslySetInnerHTML={{ __html: state.paragraph3 }}
                  className="inline-edit"
                />
              </div>

              {/* FOOTER & SIGNATURES SECTION */}
              <div className="pt-4 pb-2 px-6 relative">
                {/* Official Round Stamp Overlay (Optional) */}
                {state.showOfficialStamp && (
                  <div className="absolute right-48 bottom-4 pointer-events-none opacity-85 select-none rotate-[-6deg]">
                    <div className="w-24 h-24 rounded-full border-2 border-red-700/80 p-1 flex items-center justify-center text-center">
                      <div className="w-full h-full rounded-full border border-dashed border-red-700/70 flex flex-col items-center justify-center p-1">
                        <span className="text-[7.5px] font-bold text-red-700 leading-tight">
                          {state.schoolName.slice(0, 20)}...
                        </span>
                        <span className="text-[8px] font-extrabold text-red-800 my-0.5">
                          ★ সীলমোহর ★
                        </span>
                        <span className="text-[7px] text-red-700 font-mono">
                          {state.thanaUpazila}, {state.district}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-end justify-between">
                  {/* Left: Class Teacher signature */}
                  <div className="w-52 text-center">
                    <div className="w-full border-t-[1.6px] border-slate-800 mb-1.5" />
                    <div
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("classTeacherTitle", e.currentTarget.textContent || "")}
                      className="inline-edit font-bold text-slate-900 text-[16px]"
                    >
                      {state.classTeacherTitle}
                    </div>
                  </div>

                  {/* Optional QR Code */}
                  {state.showQrCode && (
                    <div className="text-center flex flex-col items-center">
                      <CertificateQrCode value={qrPayload} size={54} />
                      <span className="text-[10px] text-slate-500 font-mono mt-0.5">
                        যাচাইকরণ কোড
                      </span>
                    </div>
                  )}

                  {/* Right: Head Teacher signature */}
                  <div className="w-52 text-center">
                    <div className="w-full border-t-[1.6px] border-slate-800 mb-1.5" />
                    <div
                      contentEditable
                      suppressContentEditableWarning
                      onBlur={(e) => handleFieldChange("headTeacherTitle", e.currentTarget.textContent || "")}
                      className="inline-edit font-bold text-slate-900 text-[16px]"
                    >
                      {state.headTeacherTitle}
                    </div>
                    {state.headTeacherName && (
                      <div
                        contentEditable
                        suppressContentEditableWarning
                        onBlur={(e) => handleFieldChange("headTeacherName", e.currentTarget.textContent?.replace(/[()]/g, "") || "")}
                        className="inline-edit text-[13px] text-slate-600 font-medium"
                      >
                        ({state.headTeacherName})
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* HTML Code Modal */}
      {showCodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code2 className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">
                  এডিটেবল স্ট্যান্ডঅ্যালোন HTML কোড
                </h3>
              </div>
              <button
                onClick={() => setShowCodeModal(false)}
                className="text-white/70 hover:text-white text-sm"
              >
                ✕ বন্ধ করুন
              </button>
            </div>
            <div className="p-4 bg-slate-950 flex-1 overflow-auto">
              <pre className="text-xs text-emerald-400 font-mono whitespace-pre-wrap select-all">
                {rawHtmlCode}
              </pre>
            </div>
            <div className="bg-slate-100 p-4 border-t border-slate-200 flex items-center justify-between">
              <p className="text-xs text-slate-600">
                এই কোডটি যেকোনো .html ফাইলে সংরক্ষণ করে যেকোনো কম্পিউটারে অফলাইনে ওপেন করা যাবে।
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(rawHtmlCode);
                    alert("HTML কোড কপি করা হয়েছে!");
                  }}
                  className="px-4 py-2 bg-slate-800 text-white text-xs font-semibold rounded-lg hover:bg-slate-900 cursor-pointer"
                >
                  কোড কপি করুন
                </button>
                <button
                  onClick={handleDownloadHtml}
                  className="px-4 py-2 bg-emerald-600 text-white text-xs font-semibold rounded-lg hover:bg-emerald-700 cursor-pointer"
                >
                  .html ফাইল ডাউনলোড করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
