"use client";

import React, { useState } from "react";
import { SchoolSettings } from "@/db/schema";
import { X, Building2, Save, CheckCircle2 } from "lucide-react";

interface SchoolSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SchoolSettings;
  onSaved: (updated: SchoolSettings) => void;
}

export function SchoolSettingsModal({
  isOpen,
  onClose,
  settings,
  onSaved,
}: SchoolSettingsModalProps) {
  const [formData, setFormData] = useState<SchoolSettings>({ ...settings });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);
      setError("");

      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "সেটিংস সংরক্ষণ করতে ব্যর্থ হয়েছে");
      }

      setSuccess(true);
      onSaved(data.data);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1000);
    } catch (err: any) {
      setError(err.message || "সমস্যা দেখা দিয়েছে");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-blue-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-blue-300" />
            <h3 className="font-bold text-lg">বিদ্যালয়ের তথ্য ও সেটিংস</h3>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg font-medium">
              {error}
            </div>
          )}
          {success && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm rounded-lg font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>বিদ্যালয়ের তথ্য সফলভাবে সংরক্ষিত হয়েছে!</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* School Name */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                বিদ্যালয়ের পুরো নাম <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.schoolName}
                onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Established */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                স্থাপিত সাল (বাংলায়)
              </label>
              <input
                type="text"
                value={formData.establishedYear}
                onChange={(e) => setFormData({ ...formData, establishedYear: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Village */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                গ্রাম <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.village}
                onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Post Office */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                ডাকঘর <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.postOffice}
                onChange={(e) => setFormData({ ...formData, postOffice: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Thana/Upazila */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                উপজেলা / থানা <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.thanaUpazila}
                onChange={(e) => setFormData({ ...formData, thanaUpazila: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* District */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                জেলা <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.district}
                onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Memo Prefix */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                ডিফল্ট স্মারক নং প্রিফিক্স
              </label>
              <input
                type="text"
                value={formData.memoPrefix}
                onChange={(e) => setFormData({ ...formData, memoPrefix: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Head Teacher Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                প্রধান শিক্ষকের নাম
              </label>
              <input
                type="text"
                value={formData.headTeacherName}
                onChange={(e) => setFormData({ ...formData, headTeacherName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Head Teacher Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                প্রধান শিক্ষকের পদবি
              </label>
              <input
                type="text"
                value={formData.headTeacherTitle}
                onChange={(e) => setFormData({ ...formData, headTeacherTitle: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Class Teacher Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শ্রেণি শিক্ষকের পদবি
              </label>
              <input
                type="text"
                value={formData.classTeacherTitle}
                onChange={(e) => setFormData({ ...formData, classTeacherTitle: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                বিদ্যালয়ের ফোন/মোবাইল নম্বর
              </label>
              <input
                type="text"
                value={formData.phone || ""}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-100 cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-1.5 px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm font-bold shadow-md transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? "সংরক্ষণ হচ্ছে..." : "তথ্য সংরক্ষণ করুন"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
