"use client";

import React, { useState } from "react";
import { Student, SchoolSettings } from "@/db/schema";
import {
  X,
  Printer,
  CheckSquare,
  Square,
  FileCheck,
  Check,
} from "lucide-react";
import {
  generateDefaultParagraph1,
  generateDefaultParagraph2,
  generateDefaultParagraph3,
  getTodayDateBengali,
  toBengaliDigits,
} from "@/lib/bangla-utils";
import { BdSealSvg } from "./bd-seal";

interface BatchPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  settings: SchoolSettings;
}

export function BatchPrintModal({
  isOpen,
  onClose,
  students,
  settings,
}: BatchPrintModalProps) {
  const [selectedIds, setSelectedIds] = useState<number[]>(
    students.map((s) => s.id)
  );
  const [certType, setCertType] = useState("প্রত্যয়ন পত্র");

  if (!isOpen) return null;

  const toggleSelectAll = () => {
    if (selectedIds.length === students.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(students.map((s) => s.id));
    }
  };

  const toggleSelectOne = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handlePrintBatch = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("পপ-আপ উইন্ডো ব্লক করা হয়েছে। অনুগ্রহ করে ব্রাউজারের পপ-আপ অনুমোদন করুন।");
      return;
    }

    const selectedStudents = students.filter((s) => selectedIds.includes(s.id));
    const today = getTodayDateBengali();

    const certHtmlList = selectedStudents.map((student, idx) => {
      const p1 = generateDefaultParagraph1({
        studentName: student.nameBn,
        fatherName: student.fatherName,
        motherName: student.motherName,
        studentVillage: student.village,
        studentPostOffice: student.postOffice,
        studentThana: student.thanaUpazila,
        studentDistrict: student.district,
        academicYear: student.academicYear,
        studentClass: student.studentClass,
        gender: student.gender,
        rollNo: student.rollNo,
      });

      const p2 = generateDefaultParagraph2({
        gender: student.gender,
        characterRemark: student.characterRemark,
        dateOfBirth: student.dateOfBirth,
      });

      const p3 = generateDefaultParagraph3();
      const memo = `${settings.memoPrefix || "ছাই:পূ:পা/২০২৬/"}${toBengaliDigits(student.rollNo)}`;

      return `
      <div class="certificate-page">
        <div class="outer-border"></div>
        <div class="inner-border"></div>
        
        <div class="certificate-content">
          <div>
            <div class="header-top">
              <div class="memo-box">স্মারক নং : ${memo}</div>
              <div class="seal-wrap">
                <svg viewBox="0 0 100 100" width="65" height="65" fill="none">
                  <circle cx="50" cy="50" r="48" stroke="#107C41" stroke-width="2.5" fill="#fdfefe"/>
                  <circle cx="50" cy="50" r="44.5" stroke="#107C41" stroke-width="1" stroke-dasharray="2 2" fill="none"/>
                  <circle cx="50" cy="50" r="28" fill="#F42A41"/>
                  <path d="M50 32 L53 41 L62 41 L55 47 L58 56 L50 51 L42 56 L45 47 L38 41 L47 41 Z" fill="#FFD700"/>
                  <circle cx="50" cy="46" r="3" fill="#ffffff"/>
                </svg>
              </div>
              <div class="date-box">তারিখ: ${today}</div>
            </div>

            <div class="govt-titles">
              <div>${settings.ministryName}</div>
              <div>${settings.departmentName}</div>
              <div>${settings.directorateName}</div>
            </div>

            <div class="school-title">${settings.schoolName}</div>
            <div class="school-sub">
              স্থাপিত: ${settings.establishedYear}, গ্রাম: ${settings.village}, ডাকঘর: ${settings.postOffice}, উপজেলা: ${settings.thanaUpazila}, জেলা: ${settings.district}
            </div>

            <div class="badge-container">
              <span class="badge-pill">${certType}</span>
            </div>
          </div>

          <div class="body-section">
            <p>${p1}</p>
            <p>${p2}</p>
            <p>${p3}</p>
          </div>

          <div class="signatures-row">
            <div class="sign-col">
              <div class="sign-line"></div>
              <div class="sign-title">${settings.classTeacherTitle}</div>
            </div>
            <div class="sign-col">
              <div class="sign-line"></div>
              <div class="sign-title">${settings.headTeacherTitle}</div>
              ${settings.headTeacherName ? `<div class="sign-name">(${settings.headTeacherName})</div>` : ""}
            </div>
          </div>
        </div>
      </div>
      `;
    }).join("");

    const fullDoc = `<!DOCTYPE html>
    <html lang="bn">
    <head>
      <meta charset="UTF-8">
      <title>একসাথে প্রিন্ট - ${settings.schoolName}</title>
      <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          font-family: 'Hind Siliguri', sans-serif;
          background: #e2e8f0;
          color: #111827;
        }
        .certificate-page {
          width: 297mm;
          height: 208mm;
          background: #ffffff;
          padding: 13mm 16mm;
          position: relative;
          margin: 20px auto;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          page-break-after: always;
        }
        .outer-border {
          position: absolute;
          top: 6mm; left: 6mm; right: 6mm; bottom: 6mm;
          border: 1.5px solid #b8860b;
        }
        .inner-border {
          position: absolute;
          top: 9mm; left: 9mm; right: 9mm; bottom: 9mm;
          border: 5px solid #c59b27;
        }
        .certificate-content {
          position: relative;
          z-index: 2;
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        .header-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
        }
        .memo-box, .date-box { font-size: 16px; font-weight: bold; }
        .seal-wrap { text-align: center; margin-top: -6px; }
        .govt-titles {
          text-align: center;
          font-size: 14.5px;
          margin-top: 3px;
          color: #334155;
        }
        .school-title {
          text-align: center;
          font-size: 28px;
          font-weight: 800;
          margin-top: 3px;
        }
        .school-sub {
          text-align: center;
          font-size: 14px;
          color: #475569;
          margin-bottom: 8px;
        }
        .badge-container { text-align: center; margin-bottom: 12px; }
        .badge-pill {
          display: inline-block;
          background: #1e56a0;
          color: white;
          font-size: 18px;
          font-weight: bold;
          padding: 2px 24px;
          border-radius: 4px;
        }
        .body-section {
          font-size: 17px;
          line-height: 2.1;
          text-align: justify;
        }
        .body-section p { margin-bottom: 12px; }
        .signatures-row {
          display: flex;
          justify-content: space-between;
          padding-top: 20px;
        }
        .sign-col { text-align: center; width: 190px; }
        .sign-line { border-top: 1.5px solid #111; margin-bottom: 4px; }
        .sign-title { font-size: 15.5px; font-weight: bold; }
        .sign-name { font-size: 13px; color: #4b5563; }
        @media print {
          @page { size: A4 landscape; margin: 0; }
          body { background: transparent; }
          .certificate-page {
            box-shadow: none;
            margin: 0;
            width: 100vw;
            height: 100vh;
            page-break-after: always;
          }
        }
      </style>
    </head>
    <body>
      ${certHtmlList}
      <script>
        window.onload = function() {
          setTimeout(function() { window.print(); }, 400);
        };
      </script>
    </body>
    </html>`;

    printWindow.document.open();
    printWindow.document.write(fullDoc);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Printer className="w-5 h-5 text-blue-200" />
            <div>
              <h3 className="font-bold text-lg">একসাথে একাধিক শিক্ষার্থীর প্রত্যয়ন প্রিন্ট</h3>
              <p className="text-xs text-blue-100">
                এক ক্লিকে সকল শিক্ষার্থীর জন্য আলাদা আলাদা প্রত্যয়ন পত্র প্রস্তুত করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleSelectAll}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                {selectedIds.length === students.length ? (
                  <>
                    <CheckSquare className="w-4 h-4 text-blue-600" />
                    <span>সবগুলো বাতিল করুন</span>
                  </>
                ) : (
                  <>
                    <Square className="w-4 h-4 text-slate-400" />
                    <span>সব শিক্ষার্থী নির্বাচন করুন ({students.length})</span>
                  </>
                )}
              </button>
              <span className="text-xs text-slate-600 font-medium">
                নির্বাচিত: <strong>{selectedIds.length}</strong> জন
              </span>
            </div>

            {/* Cert Type */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-700">ধরন:</label>
              <select
                value={certType}
                onChange={(e) => setCertType(e.target.value)}
                className="text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-md font-medium"
              >
                <option value="প্রত্যয়ন পত্র">প্রত্যয়ন পত্র (সাধারণ)</option>
                <option value="প্রশংসাপত্র / ছাড়পত্র">প্রশংসাপত্র / ছাড়পত্র</option>
                <option value="উপবৃত্তি প্রত্যয়ন পত্র">উপবৃত্তি প্রত্যয়ন পত্র</option>
                <option value="জন্ম নিবন্ধন প্রত্যয়ন পত্র">জন্ম নিবন্ধন প্রত্যয়ন পত্র</option>
              </select>
            </div>
          </div>

          {/* Student selection list */}
          <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-200 max-h-80 overflow-y-auto">
            {students.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-sm">
                কোনো শিক্ষার্থী পাওয়া যায়নি।
              </div>
            ) : (
              students.map((st) => {
                const isSelected = selectedIds.includes(st.id);
                return (
                  <div
                    key={st.id}
                    onClick={() => toggleSelectOne(st.id)}
                    className={`flex items-center justify-between p-3 cursor-pointer transition-colors ${
                      isSelected ? "bg-blue-50/70" : "hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                          isSelected
                            ? "bg-blue-600 border-blue-600 text-white"
                            : "border-slate-300 bg-white"
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <div className="font-semibold text-sm text-slate-900">
                          {st.nameBn}
                          <span className="text-xs font-normal text-slate-500 ml-2">
                            (রোল: {st.rollNo})
                          </span>
                        </div>
                        <div className="text-xs text-slate-500">
                          শ্রেণি: {st.studentClass} | পিতা: {st.fatherName} | গ্রাম: {st.village}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono">
                      {st.gender}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-100 cursor-pointer"
          >
            বন্ধ করুন
          </button>

          <button
            type="button"
            disabled={selectedIds.length === 0}
            onClick={handlePrintBatch}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm font-bold shadow-md transition-colors disabled:opacity-50 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>নির্বাচিত {selectedIds.length} জনের প্রত্যয়ন প্রিন্ট করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
}
