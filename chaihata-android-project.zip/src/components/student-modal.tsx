"use client";

import React, { useState, useEffect } from "react";
import { Student } from "@/db/schema";
import { X, UserPlus, Save, Sparkles, CheckCircle2 } from "lucide-react";
import { toBengaliDigits } from "@/lib/bangla-utils";

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: (student: Student, generateNow?: boolean) => void;
  initialData?: Student | null;
  defaultVillage?: string;
  defaultPostOffice?: string;
  defaultThana?: string;
  defaultDistrict?: string;
}

export function StudentModal({
  isOpen,
  onClose,
  onSaved,
  initialData,
  defaultVillage = "ছাইহাটা",
  defaultPostOffice = "নিউ সোনাতলা",
  defaultThana = "সারিয়াকান্দি",
  defaultDistrict = "বগুড়া",
}: StudentModalProps) {
  const [formData, setFormData] = useState({
    nameBn: "",
    nameEn: "",
    rollNo: "",
    studentClass: "পঞ্চম",
    section: "ক",
    academicYear: "২০২৬",
    fatherName: "",
    motherName: "",
    village: defaultVillage,
    postOffice: defaultPostOffice,
    thanaUpazila: defaultThana,
    district: defaultDistrict,
    dateOfBirth: "১৮/১২/২০১৫",
    birthRegNo: "",
    gender: "ছাত্র",
    status: "নিয়মিত",
    characterRemark: "ভালো",
    phone: "",
    notes: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    if (initialData) {
      setFormData({
        nameBn: initialData.nameBn || "",
        nameEn: initialData.nameEn || "",
        rollNo: initialData.rollNo || "",
        studentClass: initialData.studentClass || "পঞ্চম",
        section: initialData.section || "ক",
        academicYear: initialData.academicYear || "২০২৬",
        fatherName: initialData.fatherName || "",
        motherName: initialData.motherName || "",
        village: initialData.village || defaultVillage,
        postOffice: initialData.postOffice || defaultPostOffice,
        thanaUpazila: initialData.thanaUpazila || defaultThana,
        district: initialData.district || defaultDistrict,
        dateOfBirth: initialData.dateOfBirth || "১৮/১২/২০১৫",
        birthRegNo: initialData.birthRegNo || "",
        gender: initialData.gender || "ছাত্র",
        status: initialData.status || "নিয়মিত",
        characterRemark: initialData.characterRemark || "ভালো",
        phone: initialData.phone || "",
        notes: initialData.notes || "",
      });
    } else {
      setFormData({
        nameBn: "",
        nameEn: "",
        rollNo: "",
        studentClass: "পঞ্চম",
        section: "ক",
        academicYear: "২০২৬",
        fatherName: "",
        motherName: "",
        village: defaultVillage,
        postOffice: defaultPostOffice,
        thanaUpazila: defaultThana,
        district: defaultDistrict,
        dateOfBirth: "১৮/১২/২০১৫",
        birthRegNo: "",
        gender: "ছাত্র",
        status: "নিয়মিত",
        characterRemark: "ভালো",
        phone: "",
        notes: "",
      });
    }
    setErrorMsg("");
  }, [initialData, defaultVillage, defaultPostOffice, defaultThana, defaultDistrict, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (generateNow = false) => {
    if (!formData.nameBn.trim()) {
      setErrorMsg("অনুগ্রহ করে শিক্ষার্থীর নাম (বাংলায়) লিখুন");
      return;
    }
    if (!formData.rollNo.trim()) {
      setErrorMsg("শ্রেণি রোল নম্বর দিন");
      return;
    }
    if (!formData.fatherName.trim()) {
      setErrorMsg("পিতার নাম লিখুন");
      return;
    }
    if (!formData.motherName.trim()) {
      setErrorMsg("মাতার নাম লিখুন");
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg("");

      const url = initialData?.id ? `/api/students/${initialData.id}` : "/api/students";
      const method = initialData?.id ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const resData = await res.json();
      if (!res.ok || !resData.success) {
        throw new Error(resData.error || "শিক্ষার্থী তথ্য সেভ করতে সমস্যা হয়েছে");
      }

      onSaved(resData.data, generateNow);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || "সংরক্ষণে ব্যর্থ হয়েছে");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <UserPlus className="w-5 h-5 text-blue-200" />
            <h3 className="font-bold text-lg">
              {initialData ? "শিক্ষার্থীর তথ্য সংশোধন করুন" : "নতুন শিক্ষার্থী এন্ট্রি দিন"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg font-medium">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Student Name Bengali */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শিক্ষার্থীর নাম (বাংলায়) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="যেমন: নুর আলম"
                value={formData.nameBn}
                onChange={(e) => setFormData({ ...formData, nameBn: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Student Name English */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শিক্ষার্থীর নাম (English - ঐচ্ছিক)
              </label>
              <input
                type="text"
                placeholder="e.g. Nur Alam"
                value={formData.nameEn}
                onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Class */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শ্রেণি <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.studentClass}
                onChange={(e) => setFormData({ ...formData, studentClass: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="শিশু শ্রেণি">শিশু শ্রেণি / প্রাক-প্রাথমিক</option>
                <option value="প্রথম">প্রথম শ্রেণি</option>
                <option value="দ্বিতীয়">দ্বিতীয় শ্রেণি</option>
                <option value="তৃতীয়">তৃতীয় শ্রেণি</option>
                <option value="চতুর্থ">চতুর্থ শ্রেণি</option>
                <option value="পঞ্চম">পঞ্চম শ্রেণি</option>
              </select>
            </div>

            {/* Roll No */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শ্রেণি রোল নম্বর <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="যেমন: ২০ বা ০১"
                value={formData.rollNo}
                onChange={(e) => setFormData({ ...formData, rollNo: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Gender */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">লিঙ্গ</label>
              <div className="flex gap-4 pt-1">
                <label className="inline-flex items-center gap-1.5 cursor-pointer text-sm">
                  <input
                    type="radio"
                    name="gender"
                    value="ছাত্র"
                    checked={formData.gender === "ছাত্র"}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span>ছাত্র</span>
                </label>
                <label className="inline-flex items-center gap-1.5 cursor-pointer text-sm">
                  <input
                    type="radio"
                    name="gender"
                    value="ছাত্রী"
                    checked={formData.gender === "ছাত্রী"}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span>ছাত্রী</span>
                </label>
              </div>
            </div>

            {/* Academic Year */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                শিক্ষাবর্ষ
              </label>
              <input
                type="text"
                placeholder="২০২৬"
                value={formData.academicYear}
                onChange={(e) => setFormData({ ...formData, academicYear: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Father's Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                পিতার নাম <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="যেমন: মোঃ অমিত হাসান"
                value={formData.fatherName}
                onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Mother's Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                মাতার নাম <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="যেমন: খাদিজা বেগম"
                value={formData.motherName}
                onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Date of Birth */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                জন্ম তারিখ (দিন/মাস/বছর)
              </label>
              <input
                type="text"
                placeholder="১৮/১২/২০১৫"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Birth Reg No */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                জন্ম নিবন্ধন নম্বর (১৭ ডিজিট)
              </label>
              <input
                type="text"
                placeholder="২০১৫১০১৯৫৪৮০০০০২০"
                value={formData.birthRegNo}
                onChange={(e) => setFormData({ ...formData, birthRegNo: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Village */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">গ্রাম</label>
              <input
                type="text"
                placeholder="ছাইহাটা"
                value={formData.village}
                onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Post Office */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">ডাকঘর</label>
              <input
                type="text"
                placeholder="নিউ সোনাতলা"
                value={formData.postOffice}
                onChange={(e) => setFormData({ ...formData, postOffice: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Thana/Upazila */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                উপজেলা / থানা
              </label>
              <input
                type="text"
                placeholder="সারিয়াকান্দি"
                value={formData.thanaUpazila}
                onChange={(e) => setFormData({ ...formData, thanaUpazila: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* District */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">জেলা</label>
              <input
                type="text"
                placeholder="বগুড়া"
                value={formData.district}
                onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            {/* Character Remark */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                আচার-আচরণ ও চরিত্র
              </label>
              <select
                value={formData.characterRemark}
                onChange={(e) => setFormData({ ...formData, characterRemark: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="ভালো">ভালো</option>
                <option value="উত্তম">উত্তম</option>
                <option value="সন্তোষজনক">সন্তোষজনক</option>
              </select>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                অভিভাবকের মোবাইল নম্বর
              </label>
              <input
                type="text"
                placeholder="০১৭xxxxxxxx"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-100 cursor-pointer"
          >
            বাতিল
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit(false)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? "সংরক্ষণ হচ্ছে..." : "শুধুমাত্র সেভ করুন"}</span>
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit(true)}
              className="inline-flex items-center gap-1.5 px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm font-bold shadow-md transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>সেভ ও ১-ক্লিকে প্রত্যয়ন বানান ➔</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
