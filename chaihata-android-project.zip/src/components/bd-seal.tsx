import React from "react";

export function BdSealSvg({ className = "w-16 h-16" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="গণপ্রজাতন্ত্রী বাংলাদেশ সরকার সিল"
    >
      {/* Outer subtle ring */}
      <circle cx="50" cy="50" r="48" stroke="#107C41" strokeWidth="2.5" fill="#fdfefe" />
      <circle cx="50" cy="50" r="44.5" stroke="#107C41" strokeWidth="1" strokeDasharray="2 2" fill="none" />

      {/* Red core circle */}
      <circle cx="50" cy="50" r="28" fill="#F42A41" />

      {/* Golden map contour / star inside red circle */}
      {/* Star / Map shape */}
      <path
        d="M50 32 L53 41 L62 41 L55 47 L58 56 L50 51 L42 56 L45 47 L38 41 L47 41 Z"
        fill="#FFD700"
        opacity="0.95"
      />
      <circle cx="50" cy="46" r="3" fill="#ffffff" opacity="0.9" />

      {/* Stars on sides */}
      <path d="M23 50 L25 54 L29 54 L26 57 L27 61 L23 58 L19 61 L20 57 L17 54 L21 54 Z" fill="#FFD700" transform="scale(0.55) translate(14, 25)" />
      <path d="M77 50 L79 54 L83 54 L80 57 L81 61 L77 58 L73 61 L74 57 L71 54 L75 54 Z" fill="#FFD700" transform="scale(0.55) translate(80, 25)" />

      {/* Circular text simulation or curved text */}
      <path id="textPathTop" d="M 18,50 A 32,32 0 1,1 82,50" fill="none" />
      <path id="textPathBottom" d="M 82,50 A 32,32 0 0,1 18,50" fill="none" />

      <text fontSize="6.2" fontWeight="bold" fill="#006A4E" letterSpacing="0.5">
        <textPath href="#textPathTop" startOffset="50%" textAnchor="middle">
          গণপ্রজাতন্ত্রী বাংলাদেশ
        </textPath>
      </text>

      <text fontSize="6.2" fontWeight="bold" fill="#006A4E" letterSpacing="1">
        <textPath href="#textPathBottom" startOffset="50%" textAnchor="middle">
          ★ সরকার ★
        </textPath>
      </text>
    </svg>
  );
}

export function BdNationalEmblemSvg({ className = "w-16 h-16" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="বাংলাদেশ জাতীয় প্রতীক"
    >
      <circle cx="50" cy="50" r="47" fill="#fffcf5" stroke="#b8860b" strokeWidth="2" />
      {/* Water lines */}
      <path d="M 28 68 Q 38 64, 50 68 T 72 68" stroke="#1d4ed8" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <path d="M 32 73 Q 42 69, 50 73 T 68 73" stroke="#1d4ed8" strokeWidth="2" fill="none" strokeLinecap="round" />
      
      {/* Water lily / Shapla */}
      <path d="M 50 44 C 50 54, 45 62, 50 64 C 55 62, 50 54, 50 44 Z" fill="#b8860b" />
      <path d="M 50 48 C 42 54, 38 60, 44 64 C 47 62, 49 56, 50 48 Z" fill="#c59b27" />
      <path d="M 50 48 C 58 54, 62 60, 56 64 C 53 62, 51 56, 50 48 Z" fill="#c59b27" />
      <path d="M 50 52 C 34 56, 32 63, 40 65 C 44 63, 48 58, 50 52 Z" fill="#d4af37" />
      <path d="M 50 52 C 66 56, 68 63, 60 65 C 56 63, 52 58, 50 52 Z" fill="#d4af37" />

      {/* Rice sheaves */}
      <path d="M 30 65 C 22 50, 24 35, 38 24 C 34 32, 33 46, 38 58" fill="none" stroke="#b8860b" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 70 65 C 78 50, 76 35, 62 24 C 66 32, 67 46, 62 58" fill="none" stroke="#b8860b" strokeWidth="2.5" strokeLinecap="round" />

      {/* Top 3 Jute leaves */}
      <path d="M 50 18 C 48 24, 48 30, 50 34 C 52 30, 52 24, 50 18 Z" fill="#006A4E" />
      <path d="M 44 22 C 45 27, 47 31, 50 33 C 48 30, 45 27, 44 22 Z" fill="#006A4E" />
      <path d="M 56 22 C 55 27, 53 31, 50 33 C 52 30, 55 27, 56 22 Z" fill="#006A4E" />

      {/* 4 Stars at the top */}
      <polygon points="39,26 40,28 42,28 40.5,29.5 41,31.5 39,30 37,31.5 37.5,29.5 36,28 38,28" fill="#b8860b" />
      <polygon points="44,23 45,25 47,25 45.5,26.5 46,28.5 44,27 42,28.5 42.5,26.5 41,25 43,25" fill="#b8860b" />
      <polygon points="56,23 57,25 59,25 57.5,26.5 58,28.5 56,27 54,28.5 54.5,26.5 53,25 55,25" fill="#b8860b" />
      <polygon points="61,26 62,28 64,28 62.5,29.5 63,31.5 61,30 59,31.5 59.5,29.5 58,28 60,28" fill="#b8860b" />
    </svg>
  );
}

export const BD_SEAL_RAW_SVG = `<svg viewBox="0 0 100 100" width="70" height="70" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="50" cy="50" r="48" stroke="#107C41" stroke-width="2.5" fill="#fdfefe"/>
  <circle cx="50" cy="50" r="44.5" stroke="#107C41" stroke-width="1" stroke-dasharray="2 2" fill="none"/>
  <circle cx="50" cy="50" r="28" fill="#F42A41"/>
  <path d="M50 32 L53 41 L62 41 L55 47 L58 56 L50 51 L42 56 L45 47 L38 41 L47 41 Z" fill="#FFD700"/>
  <circle cx="50" cy="46" r="3" fill="#ffffff"/>
  <path id="tTop" d="M 18,50 A 32,32 0 1,1 82,50" fill="none"/>
  <path id="tBot" d="M 82,50 A 32,32 0 0,1 18,50" fill="none"/>
  <text font-size="6.2" font-weight="bold" fill="#006A4E"><textPath href="#tTop" startOffset="50%" text-anchor="middle">গণপ্রজাতন্ত্রী বাংলাদেশ</textPath></text>
  <text font-size="6.2" font-weight="bold" fill="#006A4E"><textPath href="#tBot" startOffset="50%" text-anchor="middle">★ সরকার ★</textPath></text>
</svg>`;
