import React from "react";

interface QrCodeProps {
  value: string;
  size?: number;
  className?: string;
}

export function CertificateQrCode({ value, size = 64, className = "" }: QrCodeProps) {
  // Generate a deterministic 21x21 QR code matrix representation
  const matrixSize = 21;
  const grid: boolean[][] = Array(matrixSize)
    .fill(false)
    .map(() => Array(matrixSize).fill(false));

  // Helper to draw a finder pattern at (r, c)
  const drawFinder = (r: number, c: number) => {
    for (let i = 0; i < 7; i++) {
      for (let j = 0; j < 7; j++) {
        if (
          i === 0 ||
          i === 6 ||
          j === 0 ||
          j === 6 ||
          (i >= 2 && i <= 4 && j >= 2 && j <= 4)
        ) {
          grid[r + i][c + j] = true;
        }
      }
    }
  };

  // Top-left finder
  drawFinder(0, 0);
  // Top-right finder
  drawFinder(0, matrixSize - 7);
  // Bottom-left finder
  drawFinder(matrixSize - 7, 0);

  // Timing patterns
  for (let i = 8; i < matrixSize - 8; i++) {
    if (i % 2 === 0) {
      grid[6][i] = true;
      grid[i][6] = true;
    }
  }

  // Deterministic seed from value
  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = (hash * 31 + value.charCodeAt(i)) >>> 0;
  }

  // Fill in data cells
  let currentHash = hash;
  for (let r = 0; r < matrixSize; r++) {
    for (let c = 0; c < matrixSize; c++) {
      // Skip finder zones
      const inTopLeft = r < 8 && c < 8;
      const inTopRight = r < 8 && c >= matrixSize - 8;
      const inBottomLeft = r >= matrixSize - 8 && c < 8;
      const inTiming = r === 6 || c === 6;

      if (!inTopLeft && !inTopRight && !inBottomLeft && !inTiming) {
        currentHash = (currentHash * 1664525 + 1013904223) >>> 0;
        grid[r][c] = (currentHash % 10) > 4;
      }
    }
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${matrixSize} ${matrixSize}`}
      className={`bg-white p-1 rounded border border-slate-300 shadow-sm ${className}`}
      shapeRendering="crispEdges"
      aria-label="QR কোড"
    >
      <rect width={matrixSize} height={matrixSize} fill="#ffffff" />
      {grid.map((row, r) =>
        row.map((cell, c) =>
          cell ? <rect key={`${r}-${c}`} x={c} y={r} width={1} height={1} fill="#111827" /> : null
        )
      )}
    </svg>
  );
}
