import { pgTable, serial, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const schoolSettings = pgTable("school_settings", {
  id: serial("id").primaryKey(),
  schoolName: text("school_name").notNull().default("ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়"),
  establishedYear: text("established_year").notNull().default("১৯৯২"),
  village: text("village").notNull().default("ছাইহাটা"),
  postOffice: text("post_office").notNull().default("নিউ সোনাতলা"),
  thanaUpazila: text("thana_upazila").notNull().default("সারিয়াকান্দি"),
  district: text("district").notNull().default("বগুড়া"),
  division: text("division").notNull().default("রাজশাহী"),
  ministryName: text("ministry_name").notNull().default("গণপ্রজাতন্ত্রী বাংলাদেশ সরকার"),
  departmentName: text("department_name").notNull().default("প্রাথমিক ও গণশিক্ষা মন্ত্রণালয়"),
  directorateName: text("directorate_name").notNull().default("প্রাথমিক শিক্ষা অধিদপ্তর"),
  memoPrefix: text("memo_prefix").notNull().default("ছাই:পূ:পা:স:প্রা:বি/২০২৬/"),
  headTeacherName: text("head_teacher_name").notNull().default("মোঃ শফিকুল ইসলাম"),
  headTeacherTitle: text("head_teacher_title").notNull().default("প্রধান শিক্ষক"),
  classTeacherTitle: text("class_teacher_title").notNull().default("শ্রেণি শিক্ষক"),
  phone: text("phone").default(""),
  email: text("email").default(""),
  borderStyle: text("border_style").notNull().default("gold"),
  showWatermark: boolean("show_watermark").notNull().default(true),
  showQrCode: boolean("show_qr_code").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  nameBn: text("name_bn").notNull(),
  nameEn: text("name_en").default(""),
  rollNo: text("roll_no").notNull(),
  studentClass: text("student_class").notNull().default("পঞ্চম"),
  section: text("section").default("ক"),
  academicYear: text("academic_year").notNull().default("২০২৬"),
  fatherName: text("father_name").notNull(),
  motherName: text("mother_name").notNull(),
  village: text("village").notNull().default("ছাইহাটা"),
  postOffice: text("post_office").notNull().default("নিউ সোনাতলা"),
  thanaUpazila: text("thana_upazila").notNull().default("সারিয়াকান্দি"),
  district: text("district").notNull().default("বগুড়া"),
  dateOfBirth: text("date_of_birth").notNull().default("১৮/১২/২০১৫"),
  birthRegNo: text("birth_reg_no").default(""),
  gender: text("gender").notNull().default("ছাত্র"), // "ছাত্র" | "ছাত্রী"
  status: text("status").notNull().default("নিয়মিত"), // "নিয়মিত" | "উত্তীর্ণ" | "প্রাক্তন"
  characterRemark: text("character_remark").notNull().default("ভালো"),
  phone: text("phone").default(""),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const savedCertificates = pgTable("saved_certificates", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id, { onDelete: "set null" }),
  certificateType: text("certificate_type").notNull().default("প্রত্যয়ন পত্র"),
  memoNo: text("memo_no").notNull(),
  issueDate: text("issue_date").notNull(),
  studentName: text("student_name").notNull(),
  studentClass: text("student_class").notNull(),
  rollNo: text("roll_no").notNull(),
  academicYear: text("academic_year").notNull(),
  fatherName: text("father_name").default(""),
  motherName: text("mother_name").default(""),
  village: text("village").default(""),
  postOffice: text("post_office").default(""),
  thanaUpazila: text("thana_upazila").default(""),
  district: text("district").default(""),
  bodyText: text("body_text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type SchoolSettings = typeof schoolSettings.$inferSelect;
export type InsertSchoolSettings = typeof schoolSettings.$inferInsert;
export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;
export type SavedCertificate = typeof savedCertificates.$inferSelect;
export type InsertSavedCertificate = typeof savedCertificates.$inferInsert;
