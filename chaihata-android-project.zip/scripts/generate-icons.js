const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const iconsDir = path.join(__dirname, 'public', 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

function makeSvg(size, isMaskable = false) {
  const pad = isMaskable ? size * 0.15 : size * 0.05;
  const radius = size * 0.2;
  const cx = size / 2;
  const cy = size / 2;

  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1e3a8a"/>
        <stop offset="60%" stop-color="#1e56a0"/>
        <stop offset="100%" stop-color="#0284c7"/>
      </linearGradient>
      <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#fbbf24"/>
        <stop offset="100%" stop-color="#d97706"/>
      </linearGradient>
    </defs>
    
    <!-- Background rounded rect -->
    <rect width="${size}" height="${size}" rx="${isMaskable ? 0 : radius}" fill="url(#grad)"/>
    
    <!-- Outer gold circle -->
    <circle cx="${cx}" cy="${cy}" r="${(size / 2) - pad}" fill="none" stroke="url(#gold)" stroke-width="${size * 0.02}"/>

    <!-- Inner gold dashed ring -->
    <circle cx="${cx}" cy="${cy}" r="${(size / 2) - pad - (size * 0.04)}" fill="#ffffff" stroke="url(#gold)" stroke-width="${size * 0.01}" stroke-dasharray="${size * 0.02} ${size * 0.02}"/>

    <!-- Certificate Icon Silhouette -->
    <!-- Certificate Sheet -->
    <rect x="${cx - (size * 0.22)}" y="${cy - (size * 0.25)}" width="${size * 0.44}" height="${size * 0.5}" rx="${size * 0.03}" fill="#f8fafc" stroke="#1e56a0" stroke-width="${size * 0.015}"/>
    
    <!-- Certificate lines -->
    <rect x="${cx - (size * 0.15)}" y="${cy - (size * 0.18)}" width="${size * 0.3}" height="${size * 0.025}" rx="${size * 0.01}" fill="#1e56a0"/>
    <rect x="${cx - (size * 0.15)}" y="${cy - (size * 0.12)}" width="${size * 0.2}" height="${size * 0.02}" rx="${size * 0.01}" fill="#94a3b8"/>
    <rect x="${cx - (size * 0.15)}" y="${cy - (size * 0.07)}" width="${size * 0.3}" height="${size * 0.018}" rx="${size * 0.008}" fill="#64748b"/>
    <rect x="${cx - (size * 0.15)}" y="${cy - (size * 0.03)}" width="${size * 0.28}" height="${size * 0.018}" rx="${size * 0.008}" fill="#64748b"/>
    <rect x="${cx - (size * 0.15)}" y="${cy + (size * 0.01)}" width="${size * 0.25}" height="${size * 0.018}" rx="${size * 0.008}" fill="#64748b"/>
    
    <!-- Golden Seal on Certificate -->
    <circle cx="${cx + (size * 0.1)}" cy="${cy + (size * 0.13)}" r="${size * 0.06}" fill="#ef4444" stroke="#d97706" stroke-width="${size * 0.01}"/>
    <circle cx="${cx + (size * 0.1)}" cy="${cy + (size * 0.13)}" r="${size * 0.035}" fill="#fbbf24"/>
    
    <!-- Star on Seal -->
    <polygon points="${cx + (size * 0.1)},${cy + (size * 0.105)} ${cx + (size * 0.11)},${cy + (size * 0.122)} ${cx + (size * 0.125)},${cy + (size * 0.122)} ${cx + (size * 0.113)},${cy + (size * 0.132)} ${cx + (size * 0.118)},${cy + (size * 0.145)} ${cx + (size * 0.1)},${cy + (size * 0.136)} ${cx + (size * 0.082)},${cy + (size * 0.145)} ${cx + (size * 0.087)},${cy + (size * 0.132)} ${cx + (size * 0.075)},${cy + (size * 0.122)} ${cx + (size * 0.09)},${cy + (size * 0.122)}" fill="#ffffff"/>
  </svg>`;
}

async function generate() {
  const sizes = [
    { name: 'icon-192.png', size: 192, maskable: false },
    { name: 'icon-512.png', size: 512, maskable: false },
    { name: 'icon-maskable-192.png', size: 192, maskable: true },
    { name: 'icon-maskable-512.png', size: 512, maskable: true },
    { name: 'apple-touch-icon.png', size: 180, maskable: false },
  ];

  for (const item of sizes) {
    const svg = makeSvg(item.size, item.maskable);
    const dest = path.join(iconsDir, item.name);
    await sharp(Buffer.from(svg))
      .png()
      .toFile(dest);
    console.log(`Generated: ${dest}`);
  }

  // Also save SVG icon
  fs.writeFileSync(path.join(iconsDir, 'icon.svg'), makeSvg(512, false));
}

generate().catch(err => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
