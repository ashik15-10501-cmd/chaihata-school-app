# ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয় — Android অ্যাপ

এই ফোল্ডারটি একটি সম্পূর্ণ **Android Studio (Java + WebView) প্রজেক্ট**। এখান থেকে APK তৈরি করে যে কোনো Android ফোনে ইনস্টল করা যাবে।

- **অ্যাপের নাম:** ছাইহাটা পূর্ব পাড়া সনদ অ্যাপ
- **Application ID:** `bd.gov.chaihatapurbapara.school`
- **ন্যূনতম Android:** 7.0 (API 24)
- **বিদ্যালয়:** ছাইহাটা পূর্ব পাড়া সরকারি প্রাথমিক বিদ্যালয়
- **ঠিকানা:** গ্রাম: ছাইহাটা, ডাকঘর: নিউ সোনাতলা, উপজেলা/থানা: সারিয়াকান্দি, জেলা: বগুড়া

## অ্যাপে যা আছে

1. **ড্যাশবোর্ড** — মোট ছাত্র, অধ্যয়নরত, ইস্যুকৃত সনদ, শিক্ষাবর্ষ।
2. **ছাত্র এন্ট্রি ও তালিকা** — নতুন ছাত্র, সম্পাদনা, মুছে ফেলা, সার্চ ও ফিল্টার।
3. **সনদ তৈরি** — ৬ ধরনের সনদ (প্রত্যয়ন, চারিত্রিক, উপস্থিতি, ছাড়পত্র, ভর্তি, ফলাফল), লাইভ A4 প্রিভিউ, স্বয়ংক্রিয় স্মারক নং।
4. **সনদ আর্কাইভ** — পুরোনো সনদ দেখা, প্রিন্ট ও মুছে ফেলা।
5. **স্কুল প্রোফাইল** — বিদ্যালয়ের নাম, ঠিকানা, প্রধান/শ্রেণি শিক্ষকের নাম।
6. **প্রিন্ট / PDF** — Android-এর নিজস্ব প্রিন্ট ফ্রেমওয়ার্ক দিয়ে সরাসরি PDF।
7. **ব্যাকআপ** — JSON ব্যাকআপ ফোনের **Downloads** ফোল্ডারে সেভ ও পুনরুদ্ধার।
8. **সম্পূর্ণ অফলাইন** — সব তথ্য ফোনের ভেতরেই (localStorage) থাকে; ইন্টারনেট দরকার নেই।

## 📱 শুধু মোবাইল দিয়ে APK (কম্পিউটার ছাড়া) — সবচেয়ে সহজ

**প্রয়োজন:** শুধু একটি GitHub অ্যাকাউন্ট (বিনামূল্যে)।

1. ফোনের ব্রাউজারে **github.com/new** → নাম দিন `chaihata-school-app` → **Create repository**।
2. **Add file → Upload files** → `chaihata-android-project.zip` আপলোড → **Commit changes**
   (ফাইলের নাম বদলাবেন না, রিপোর রুটে রাখুন)।
3. **Add file → Create new file** → নাম দিন `.github/workflows/build-apk.yml`
   → নিচের কোডটি পেস্ট → **Commit changes**। কমিট হলেই বিল্ড শুরু হবে।
4. **Actions** ট্যাব → `Build APK` → সবুজ ✓ (৩–৫ মিনিট)।
5. রিপোর **Releases → apk-latest → Chaihata-School-App.apk** ট্যাপ করে ডাউনলোড → ইনস্টল
   ("Install unknown apps" অনুমতি দিন)।

> সুবিধা: APK সরাসরি Release-এ থাকে, ফোনে ZIP আনজিপ করতে হয় না।
> কম্পিউটার থাকলে `chaihata-github-repo.zip` আনজিপ করে পুরো ফোল্ডার ড্র্যাগ করে আপলোড করলেই
> workflow ফাইলসহ সব একসাথে যাবে — ৩ নম্বর ধাপ বাদ।

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Find Android project
        run: |
          if [ -f chaihata-android-project.zip ]; then
            mkdir -p project && unzip -q chaihata-android-project.zip -d project
          elif [ -f android/settings.gradle ]; then
            cp -r android project
          else
            echo "Android project not found" && exit 1
          fi
          ls -la project

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - uses: android-actions/setup-android@v3

      - name: Install Android SDK
        run: |
          yes | sdkmanager --licenses > /dev/null 2>&1 || true
          sdkmanager "platforms;android-34" "build-tools;34.0.0"

      - uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: "8.7"

      - name: Build APK
        working-directory: project
        run: gradle assembleDebug --no-daemon

      - name: Collect APK
        run: cp project/app/build/outputs/apk/debug/app-debug.apk Chaihata-School-App.apk

      - uses: actions/upload-artifact@v4
        with:
          name: Chaihata-School-APK
          path: Chaihata-School-App.apk

      - name: Publish APK download link
        uses: softprops/action-gh-release@v2
        with:
          tag_name: apk-latest
          name: Chaihata School App (latest)
          files: Chaihata-School-App.apk
          make_latest: true
```

**একদম APK ছাড়াই:** Chrome-এ `chaihata-school-certificate.html` খুলে ⠇ → **Install app**।

## APK বানানোর ধাপ## APK বানানোর ধাপ

### ১. Android Studio ইনস্টল করুন
- ডাউনলোড: <https://developer.android.com/studio>
- ইনস্টল করে খুলুন (প্রথমবার SDK ডাউনলোড হতে কিছুক্ষণ লাগবে)।

### ২. প্রজেক্ট খুলুন
- এই ZIP ফাইলটি আনজিপ করুন।
- Android Studio → **File → Open** → `android` ফোল্ডারটি নির্বাচন করুন → **OK**।
- প্রথমবার Gradle sync হতে দিন (ইন্টারনেট প্রয়োজন, একবারই)।

### ৩. APK বিল্ড করুন (পরীক্ষার জন্য)
- মেনু: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- তৈরি হওয়া ফাইল: `app/build/outputs/apk/debug/app-debug.apk`
- Android Studio-র নিচে ডান দিকে “locate” লিংকে ক্লিক করলেই ফাইলটি পাওয়া যাবে।

### ৪. ফোনে ইনস্টল করুন
- `app-debug.apk` ফোনে কপি করুন (USB, Bluetooth বা Google Drive)।
- ফোনে ফাইলটি খুলে **Install** দিন; প্রয়োজন হলে “Install unknown apps” অনুমতি দিন।
- অ্যাপটি হোম স্ক্রিনে **ছাইহাটা পূর্ব পাড়া সনদ অ্যাপ** নামে বসবে।

### ৫. Play Store-এ দেওয়ার জন্য signed APK / AAB
- মেনু: **Build → Generate Signed Bundle / APK**
- **Android App Bundle** (Play Store) অথবা **APK** নির্বাচন করুন।
- নতুন keystore তৈরি করুন (পাসওয়ার্ড সংরক্ষণ করুন) → **release** বিল্ড → **Finish**।
- ফাইল: `app/build/outputs/apk/release/app-release.apk` বা `app/build/outputs/bundle/release/app-release.aab`

## অ্যাপের ভেতরের HTML বদলাতে চাইলে

অ্যাপের সব স্ক্রিন চলে `app/src/main/assets/index.html` ফাইল থেকে। নতুন সংস্করণের HTML ফাইল নাম একই রেখে এখানে প্রতিস্থাপন করলেই অ্যাপ হালনাগাদ হবে।

`index.html`-এ থাকা `AndroidBridge` সেতু দুটি সুবিধা দেয়:
- `AndroidBridge.saveFile(name, mime, base64)` → ফোনের Downloads ফোল্ডারে সেভ
- `AndroidBridge.printPage()` → Android print dialog (PDF/প্রিন্টার)

## ফোল্ডার কাঠামো

```
android/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html          ← সম্পূর্ণ অফলাইন অ্যাপ
        ├── java/bd/gov/chaihatapurbapara/school/MainActivity.java
        └── res/ (icons, theme, strings)
```

> **টিপস:** Gradle wrapper-এর JAR ফাইলটি Android Studio নিজেই তৈরি করে নেয়। যদি “gradle-wrapper.jar not found” দেখায়, Android Studio-তে **File → Sync Project with Gradle Files** চাপুন, অথবা টার্মিনালে `gradle wrapper` চালান।
