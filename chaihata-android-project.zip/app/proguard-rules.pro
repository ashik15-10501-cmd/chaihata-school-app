# WebView JavaScript interface রাখতে হবে
-keepclassmembers class bd.gov.chaihatapurbapara.school.MainActivity$AndroidBridge {
    public *;
}
